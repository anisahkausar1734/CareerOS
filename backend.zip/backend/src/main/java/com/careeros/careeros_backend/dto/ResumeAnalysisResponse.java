package com.careeros.careeros_backend.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ResumeAnalysisResponse {

    private List<String> skills;

    private String education;

    private Integer projectCount;

    private Integer resumeScore;

    private List<String> strengths;

    private List<String> weaknesses;

    private List<String> missingSkills;

    private String summary;

    private Integer roleAlignmentScore;

private Integer skillsCoverageScore;

private Integer projectStrengthScore;

private Integer atsScore;

private Integer keywordScore;

private Integer formattingScore;

private Integer sectionScore;

private Integer readabilityScore;

private List<String> missingKeywords;

private List<String> improvements;

private String verdict;

private Integer internshipReadiness;

private Integer jobReadiness;


}