package com.careeros.careeros_backend.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "resume_analysis")
public class ResumeAnalysis {

    @Id
    private String id;

    private String email;

    private Integer resumeScore;

    private Integer atsScore;

    private Integer keywordScore;

    private Integer formattingScore;

    private Integer sectionScore;

    private Integer readabilityScore;

    private Integer roleAlignmentScore;

    private Integer skillsCoverageScore;

    private Integer projectStrengthScore;

    private Integer internshipReadiness;

    private Integer jobReadiness;

    private List<String> strengths;

    private List<String> weaknesses;

    private List<String> missingSkills;

    private List<String> missingKeywords;

    private List<String> improvements;

    private String verdict;

    private String summary;

    private LocalDateTime analyzedAt;
}