package com.careeros.careeros_backend.service;

import com.careeros.careeros_backend.dto.ResumeAnalysisResponse;
import com.careeros.careeros_backend.repository.ResumeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.careeros.careeros_backend.model.StudentProfile;
import com.careeros.careeros_backend.repository.StudentProfileRepository;
import com.careeros.careeros_backend.model.Project;
import com.careeros.careeros_backend.model.ResumeAnalysis;
import com.careeros.careeros_backend.repository.ProjectRepository;
import com.careeros.careeros_backend.repository.ResumeAnalysisRepository;

import java.util.Comparator;
import java.util.stream.Collectors;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ResumeAnalysisService {

private final ResumeRepository resumeRepository;
private final GeminiService geminiService;
private final StudentProfileRepository
        studentProfileRepository;
private final ProjectRepository
        projectRepository;
private final ResumeAnalysisRepository
        resumeAnalysisRepository;




public ResumeAnalysisResponse
getCachedAnalysis(
        String email
) {

    return resumeAnalysisRepository
            .findByEmail(email)
            .map(this::mapToResponse)
            .orElse(
                    ResumeAnalysisResponse
                            .builder()
                            .summary(
                                    "No analysis found"
                            )
                            .build()
            );
}       


        public ResumeAnalysisResponse reanalyzeResume(
        String email
) {

    resumeAnalysisRepository
            .findByEmail(email)
            .ifPresent(
                    resumeAnalysisRepository::delete
            );

    return analyzeResume(email);
}

    public ResumeAnalysisResponse analyzeResume(
        String email
) {

var existingAnalysis =

        resumeAnalysisRepository
                .findByEmail(email);

if(existingAnalysis.isPresent()) {

    System.out.println(
            "Returning Saved Resume Analysis"
    );

    return mapToResponse(
            existingAnalysis.get()
    );
}

    var resume =
            resumeRepository
                    .findByEmail(email)
                    .orElseThrow(
                            () -> new RuntimeException(
                                    "Resume not found"
                            )
                    );

    StudentProfile profile =
        studentProfileRepository
                .findByEmail(email)
                .orElseThrow(
                        () -> new RuntimeException(
                                "Profile not found"
                        )
                );                
List<Project> projects =
        projectRepository
                .findByEmail(
                        email
                );


List<Project> topProjects =
        projects.stream()
                .filter(
                        p ->
                                p.getProjectScore()
                                != null
                )
                .sorted(
                        Comparator.comparing(
                                Project::getProjectScore
                        ).reversed()
                )
                .limit(3)
                .collect(
                        Collectors.toList()
                );
                
                double projectStrengthScore = 0;

                if(topProjects.size() == 1) {

    projectStrengthScore =
            topProjects.get(0)
                    .getProjectScore();
}
else if(topProjects.size() == 2) {

    projectStrengthScore =

            topProjects.get(0)
                    .getProjectScore()

            * 0.60

            +

            topProjects.get(1)
                    .getProjectScore()

            * 0.40;
}
else if(topProjects.size() >= 3) {

    projectStrengthScore =

            topProjects.get(0)
                    .getProjectScore()

            * 0.50

            +

            topProjects.get(1)
                    .getProjectScore()

            * 0.30

            +

            topProjects.get(2)
                    .getProjectScore()

            * 0.20;
}

   String prompt = """
Analyze this resume for the student's career goal.

Student Information:

Dream Role:
%s

Current Year:
%s

Degree:
%s

Branch:
%s

Career Readiness:
%s

Current Skills:
%s

PROJECT INTELLIGENCE

Project Count:
%d

Top Project Score:
%.0f

Resume:

%s

Return ONLY:

SKILLS=skill1|skill2|skill3

EDUCATION=text

RESUME_SCORE=number

ATS_SCORE=number

KEYWORD_SCORE=number

FORMATTING_SCORE=number

SECTION_SCORE=number

READABILITY_SCORE=number

MISSING_KEYWORDS=item1|item2|item3

IMPROVEMENTS=item1|item2|item3

VERDICT=text

ROLE_ALIGNMENT=number

SKILLS_COVERAGE=number

PROJECT_STRENGTH=number

INTERNSHIP_READINESS=number

JOB_READINESS=number

STRENGTHS=item1|item2|item3

WEAKNESSES=item1|item2|item3

MISSING_SKILLS=item1|item2|item3

SUMMARY=text

SKILLS_COVERAGE=number

PROJECT_STRENGTH=number

PROJECTS=number

INTERNSHIP_READINESS=number

JOB_READINESS=number

STRENGTHS=item1|item2|item3

WEAKNESSES=item1|item2|item3

MISSING_SKILLS=item1|item2|item3

Use | as separator.

Never use commas between items.

SUMMARY=text

Rules:

- All scores between 0 and 100
- No markdown
- No extra text
"""
.formatted(
        profile.getDreamRole(),
        profile.getCurrentYear(),
        profile.getDegree(),
        profile.getBranch(),
        profile.getCareerReadiness(),
        profile.getSkills(),

        projects.size(),

        projectStrengthScore,

        resume.getResumeText()
);
    String response;

try {
System.out.println(
        prompt
);
    response =
            geminiService
                    .askGeminiCustom(
                            prompt
                    );

} catch (Exception e) {

    System.out.println(
            "Gemini Error: "
            + e.getMessage()
    );

    var savedAnalysis =
            resumeAnalysisRepository
                    .findByEmail(email);

    if(savedAnalysis.isPresent()) {

        System.out.println(
                "Returning Cached Analysis"
        );

        return mapToResponse(
                savedAnalysis.get()
        );
    }

    return ResumeAnalysisResponse
            .builder()
            .summary(
                    "No previous analysis found."
            )
            .build();
}

                    System.out.println(
        "GEMINI RESPONSE:\n"
        + response
);

    ResumeAnalysisResponse result =
            new ResumeAnalysisResponse();

    try {

        String[] lines =
                response.split("\n");

        for(String line : lines) {

            if(line.startsWith("STRENGTHS=")) {

    String value =
            line.replace(
                    "STRENGTHS=",
                    ""
            );

    result.setStrengths(
            List.of(
                    value.split("\\|")
            )
    );
}

if(line.startsWith("WEAKNESSES=")) {

    String value =
            line.replace(
                    "WEAKNESSES=",
                    ""
            );

    result.setWeaknesses(
            List.of(
                    value.split("\\|")
            )
    );
}

if(line.startsWith("MISSING_SKILLS=")) {

    String value =
            line.replace(
                    "MISSING_SKILLS=",
                    ""
            );

    result.setMissingSkills(
            List.of(
                    value.split("\\|")
            )
    );
}

if(line.startsWith("KEYWORD_SCORE=")) {

    result.setKeywordScore(
            Integer.parseInt(
                    line.replace(
                            "KEYWORD_SCORE=",
                            ""
                    ).trim()
            )
    );
}

if(line.startsWith("FORMATTING_SCORE=")) {

    result.setFormattingScore(
            Integer.parseInt(
                    line.replace(
                            "FORMATTING_SCORE=",
                            ""
                    ).trim()
            )
    );
}

if(line.startsWith("SECTION_SCORE=")) {

    result.setSectionScore(
            Integer.parseInt(
                    line.replace(
                            "SECTION_SCORE=",
                            ""
                    ).trim()
            )
    );
}

if(line.startsWith("READABILITY_SCORE=")) {

    result.setReadabilityScore(
            Integer.parseInt(
                    line.replace(
                            "READABILITY_SCORE=",
                            ""
                    ).trim()
            )
    );
}

if(line.startsWith("MISSING_KEYWORDS=")) {

    result.setMissingKeywords(
            List.of(
                    line.replace(
                            "MISSING_KEYWORDS=",
                            ""
                    ).split("\\|")
            )
    );
}

if(line.startsWith("IMPROVEMENTS=")) {

    result.setImprovements(
            List.of(
                    line.replace(
                            "IMPROVEMENTS=",
                            ""
                    ).split("\\|")
            )
    );
}

if(line.startsWith("VERDICT=")) {

    result.setVerdict(
            line.replace(
                    "VERDICT=",
                    ""
            )
    );
}



if(line.startsWith("SUMMARY=")) {

    result.setSummary(
            line.replace(
                    "SUMMARY=",
                    ""
            )
    );
}

            if(line.startsWith("SKILLS=")) {

                String skillsText =
                        line.replace(
                                "SKILLS=",
                                ""
                        );

                result.setSkills(
                        List.of(
                                skillsText.split("\\|")
                        )
                );
            }

            if(line.startsWith("EDUCATION=")) {

                result.setEducation(
                        line.replace(
                                "EDUCATION=",
                                ""
                        )
                );
            }

            if(line.startsWith("PROJECTS=")) {

                result.setProjectCount(
                        Integer.parseInt(
                                line.replace(
                                        "PROJECTS=",
                                        ""
                                ).trim()
                        )
                );
            }

if(line.startsWith(
        "ROLE_ALIGNMENT="
)) {

    result.setRoleAlignmentScore(
            Integer.parseInt(
                    line.replace(
                            "ROLE_ALIGNMENT=",
                            ""
                    ).trim()
            )
    );
}

if(line.startsWith(
        "SKILLS_COVERAGE="
)) {

    result.setSkillsCoverageScore(
            Integer.parseInt(
                    line.replace(
                            "SKILLS_COVERAGE=",
                            ""
                    ).trim()
            )
    );
}


if(line.startsWith(
        "PROJECT_STRENGTH="
)) {

    result.setProjectStrengthScore(
            Integer.parseInt(
                    line.replace(
                            "PROJECT_STRENGTH=",
                            ""
                    ).trim()
            )
    );
}


if(line.startsWith(
        "ATS_SCORE="
)) {

    result.setAtsScore(
            Integer.parseInt(
                    line.replace(
                            "ATS_SCORE=",
                            ""
                    ).trim()
            )
    );
}


if(line.startsWith(
        "INTERNSHIP_READINESS="
)) {

    result.setInternshipReadiness(
            Integer.parseInt(
                    line.replace(
                            "INTERNSHIP_READINESS=",
                            ""
                    ).trim()
            )
    );
}


if(line.startsWith(
        "JOB_READINESS="
)) {

    result.setJobReadiness(
            Integer.parseInt(
                    line.replace(
                            "JOB_READINESS=",
                            ""
                    ).trim()
            )
    );
}


           if(line.startsWith(
        "RESUME_SCORE="
)) {

    result.setResumeScore(
            Integer.parseInt(
                    line.replace(
                            "RESUME_SCORE=",
                            ""
                    ).trim()
            )
    );
}
        }

    } catch(Exception e) {

        e.printStackTrace();
    }
System.out.println(
        "========== TOP PROJECTS =========="
);

topProjects.forEach(
        p -> System.out.println(
                p.getProjectName()
                + " -> "
                + p.getProjectScore()
        )
);

System.out.println(
        "Calculated Project Strength = "
        + projectStrengthScore
);

result.setProjectStrengthScore(
        (int) Math.round(
                projectStrengthScore
        )
);
int calculatedResumeScore =

(int)

(
        result.getAtsScore() * 0.25

        +

        result.getSkillsCoverageScore() * 0.25

        +

        projectStrengthScore * 0.25

        +

        85 * 0.10

        +

        result.getRoleAlignmentScore() * 0.10

        +

        80 * 0.05
);

result.setResumeScore(
        calculatedResumeScore
);

int internshipReadiness =

(int)

(
        result.getSkillsCoverageScore() * 0.30

        +

        projectStrengthScore * 0.30

        +

        calculatedResumeScore * 0.15

        +

        result.getRoleAlignmentScore() * 0.15

        +

        profile.getCareerReadiness() * 0.10
);



int jobReadiness =

(int)

(
        result.getSkillsCoverageScore() * 0.25

        +

        projectStrengthScore * 0.25

        +

        calculatedResumeScore * 0.20

        +

        result.getRoleAlignmentScore() * 0.15

        +

        profile.getCareerReadiness() * 0.15
);

result.setJobReadiness(
        jobReadiness
);

result.setInternshipReadiness(
        internshipReadiness
);


resumeAnalysisRepository.save(

        ResumeAnalysis.builder()

                .email(email)

                .resumeScore(
                        result.getResumeScore()
                )

                .atsScore(
                        result.getAtsScore()
                )

                .keywordScore(
                        result.getKeywordScore()
                )

                .formattingScore(
                        result.getFormattingScore()
                )

                .sectionScore(
                        result.getSectionScore()
                )

                .readabilityScore(
                        result.getReadabilityScore()
                )

                .roleAlignmentScore(
                        result.getRoleAlignmentScore()
                )

                .skillsCoverageScore(
                        result.getSkillsCoverageScore()
                )

                .projectStrengthScore(
                        result.getProjectStrengthScore()
                )

                .internshipReadiness(
                        result.getInternshipReadiness()
                )

                .jobReadiness(
                        result.getJobReadiness()
                )

                .strengths(
                        result.getStrengths()
                )

                .weaknesses(
                        result.getWeaknesses()
                )

                .missingSkills(
                        result.getMissingSkills()
                )

                .missingKeywords(
                        result.getMissingKeywords()
                )

                .improvements(
                        result.getImprovements()
                )

                .verdict(
                        result.getVerdict()
                )

                .summary(
                        result.getSummary()
                )

                .analyzedAt(
                        java.time.LocalDateTime.now()
                )

                .build()
);


    return result;
}
private ResumeAnalysisResponse mapToResponse(
        ResumeAnalysis analysis
) {

    return ResumeAnalysisResponse.builder()

            .resumeScore(
                    analysis.getResumeScore()
            )

            .atsScore(
                    analysis.getAtsScore()
            )

            .keywordScore(
                    analysis.getKeywordScore()
            )

            .formattingScore(
                    analysis.getFormattingScore()
            )

            .sectionScore(
                    analysis.getSectionScore()
            )

            .readabilityScore(
                    analysis.getReadabilityScore()
            )

            .roleAlignmentScore(
                    analysis.getRoleAlignmentScore()
            )

            .skillsCoverageScore(
                    analysis.getSkillsCoverageScore()
            )

            .projectStrengthScore(
                    analysis.getProjectStrengthScore()
            )

            .internshipReadiness(
                    analysis.getInternshipReadiness()
            )

            .jobReadiness(
                    analysis.getJobReadiness()
            )

            .strengths(
                    analysis.getStrengths()
            )

            .weaknesses(
                    analysis.getWeaknesses()
            )

            .missingSkills(
                    analysis.getMissingSkills()
            )

            .missingKeywords(
                    analysis.getMissingKeywords()
            )

            .improvements(
                    analysis.getImprovements()
            )

            .verdict(
                    analysis.getVerdict()
            )

            .summary(
                    analysis.getSummary()
            )

            .build();
}

}