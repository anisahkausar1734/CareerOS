package com.careeros.careeros_backend.service;

import com.careeros.careeros_backend.dto.SkillGapResponse;
import com.careeros.careeros_backend.repository.StudentProfileRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.careeros.careeros_backend.model.StudentProfile;
import com.careeros.careeros_backend.model.Resume;
import com.careeros.careeros_backend.repository.ResumeRepository;
import com.careeros.careeros_backend.model.SkillGapAnalysis;
import com.careeros.careeros_backend.repository.SkillGapAnalysisRepository;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.List;
@RequiredArgsConstructor
@Service
public class SkillGapService {

    private final StudentProfileRepository
            studentProfileRepository;

private final ResumeRepository
        resumeRepository;

private final SkillGapAnalysisRepository
        skillGapAnalysisRepository;

private final GeminiService
        geminiService;

private Integer calculateReadiness(
        StudentProfile profile
) {

    int score = 10;

    if(Boolean.TRUE.equals(
            profile.getSkillGapCompleted()
    )) score += 20;

    if(Boolean.TRUE.equals(
            profile.getRoadmapCompleted()
    )) score += 20;

    if(Boolean.TRUE.equals(
            profile.getResumeAnalysisCompleted()
    )) score += 20;

    if(Boolean.TRUE.equals(
            profile.getInterviewCompleted()
    )) score += 15;

    if(Boolean.TRUE.equals(
            profile.getApplicationsStarted()
    )) score += 15;

    return score;
}

  
  public SkillGapResponse getSkillGap(
        String email
) {

    StudentProfile profile =
            studentProfileRepository
                    .findByEmail(email)
                    .orElseThrow(
                            () -> new RuntimeException(
                                    "Profile not found"
                            )
                    );
                    System.out.println("Dream Role: " + profile.getDreamRole());
System.out.println("Current Year: " + profile.getCurrentYear());
System.out.println("Graduation Year: " + profile.getGraduationYear());
System.out.println("Skills: " + profile.getSkills());

                    Resume resume = resumeRepository
        .findByEmail(email)
        .orElse(null);

boolean resumeUploaded =
        resume != null;

        String resumeContent =
        resumeUploaded
                ? resume.getResumeText()
                : "";

                List<String> currentSkills =
        profile.getSkills() == null
                ? List.of()
                : profile.getSkills();





String resumeFingerprint =
        resumeUploaded
                ? String.valueOf(resume.getUploadedAt())
                : "NO_RESUME";

String cacheKey = String.join(
        "|",
        profile.getDreamRole() == null ? "" : profile.getDreamRole(),
        String.valueOf(profile.getCurrentYear()),
        String.valueOf(profile.getGraduationYear()),
        String.join(",", currentSkills),
        resumeFingerprint
);

System.out.println("========== SKILL GAP DEBUG ==========");
System.out.println("Skill Gap Analysis generated successfully.");
System.out.println("=====================================");

String profileHash =
        generateProfileHash(cacheKey);

SkillGapAnalysis cached =
        skillGapAnalysisRepository
                .findByEmail(email)
                .orElse(null);


                if (
        cached != null &&
        cached.getProfileHash() != null &&
        cached.getProfileHash().equals(profileHash)
) {

    System.out.println("Returning cached Skill Gap Analysis...");

   return mapToResponse(cached);
}

    
         String prompt = """

You are the AI Career Intelligence Engine of CareerOS.

Your responsibility is NOT to create a roadmap.

Your responsibility is to analyze the student's current career position and provide clear, personalized career intelligence that removes confusion and helps the student understand where they stand and what they should focus on next.

The student should finish reading this analysis with confidence and clarity.

==================================================

STUDENT PROFILE

Dream Role:
%s

Current Academic Year:
%s

Graduation Year:
%s

Current Skills:
%s

Resume Available:
%s

Resume Content:
%s

==================================================

ANALYSIS RULES

1. Consider the student's academic year and graduation year before making recommendations.

2. If no skills are provided, assume the student is a complete beginner.

3. If a resume is available, use it to identify additional strengths and skills.

4. Never overwhelm the student.

5. Never generate long paragraphs.

6. Every recommendation should be concise and actionable.

7. Never generate weekly plans or roadmap steps.

8. Never generate motivational quotes.

9. Every recommendation must be personalized.

10. Think like an experienced Software Engineer, Technical Mentor and Hiring Manager.

==================================================

OUTPUT FORMAT

CURRENT_STAGE=
(one of: Foundation, Beginner, Intermediate, Advanced)

CAREER_POSITION=
(one short sentence)

MATCH=
(integer between 0-100)

TIME_TO_JOB_READY=
(one sentence)

LEARNING_ORDER=
(skill1,skill2,skill3,skill4,skill5...)

TOP_INSIGHTS=
(insight1,insight2,insight3,insight4,insight5,insight6)

FOCUS_NOW=
(item1,item2,item3,item4)

CORE=
(skill1,skill2,...)

PRIORITY=
(skill1,skill2,...)

MISSING=
(skill1,skill2,...)

ADVANCED=
(skill1,skill2,...)

PROJECTS=
(project1,project2,project3...)

CERTIFICATIONS=
(certification1,certification2...)

RESOURCES=
(resource1,resource2...)

EMPLOYER_EXPECTATIONS=
(point1,point2,point3,point4)

COMMON_MISTAKES=
(point1,point2,point3,point4)

INDUSTRY_ADVICE=
(point1,point2,point3,point4)

==================================================

VERY IMPORTANT

Every insight must be less than 12 words.

Avoid paragraphs.

Avoid numbering.

Avoid markdown.

Avoid explanations.

Return ONLY the following fields.

Do not add explanations.

Do not use markdown.

Do not number anything.

Do not include extra text.

If a value is unavailable, return an empty value.

Example:

CURRENT_STAGE=
CAREER_POSITION=
...

Return ONLY the fields above.

""".formatted(

profile.getDreamRole(),

profile.getCurrentYear(),

profile.getGraduationYear(),

currentSkills.isEmpty()
        ? "No skills provided"
        : String.join(", ", currentSkills),

resumeUploaded
        ? "YES"
        : "NO",

resumeContent

);
   String response;

try {

    System.out.println("Calling Gemini...");

    response =
            geminiService.askGeminiCustom(prompt);

    System.out.println("Gemini call completed.");

    System.out.println(response);

}
catch (Exception e) {

    System.out.println("Gemini failed!");

    e.printStackTrace();

    throw e;

}
System.out.println("========== GEMINI RESPONSE ==========");
System.out.println(response);
System.out.println("=====================================");

           if (
        response == null
        ||
        response.isBlank()
        ||
        response.contains("temporarily unavailable")
        ||
        response.contains("parsing failed")
)  {

    profile.setSkillGapCompleted(
            true
    );

    profile.setCareerReadiness(
            calculateReadiness(
                    profile
            )
    );

   profile.setCurrentStage(
        "SKILL GAP COMPLETED"
);
profile.setLatestMissingSkills(List.of());

profile.setLatestPrioritySkills(List.of());


    studentProfileRepository
            .save(profile);


           

    return SkillGapResponse.builder()

            .targetRole(
                    profile.getDreamRole()
            )

            .currentSkills(
        profile.getSkills() == null
                ? List.of()
                : profile.getSkills()
)
           .recommendedResources(List.of())

            .skillMatchPercentage(
                    60
            )
            .readinessScore(
                    60
            )
            .prioritySkills(List.of())

            .recommendedResources(List.of())

          .resumeConsidered(resumeUploaded)

      .currentStage("Foundation")

.careerPosition("Career analysis unavailable")

.timeToJobReady("Unknown")

.learningOrder(List.of())

.topInsights(List.of())

.focusNow(List.of())

.employerExpectations(List.of())

.commonMistakes(List.of())

.industryAdvice(List.of())    
            .build();
}

   Integer match = 0;




String currentStage = "";

String careerPosition = "";

String timeToJobReady = "";

List<String> learningOrder = List.of();

List<String> topInsights = List.of();

List<String> focusNow = List.of();

List<String> employerExpectations = List.of();

List<String> commonMistakes = List.of();

List<String> industryAdvice = List.of();

List<String> missingSkills = List.of();

List<String> prioritySkills = List.of();

List<String> coreSkills = List.of();

List<String> advancedSkills = List.of();

List<String> recommendedProjects = List.of();

List<String> recommendedCertifications = List.of();

List<String> resources = List.of();

  try {

    if (
            response == null
            ||
            response.isBlank()
    ) {

        throw new RuntimeException(
                "Gemini returned an empty response."
        );

    }

    String[] lines =
            response
                    .replace("\r", "")
                    .split("\n");

    for (String rawLine : lines) {

        String line =
                rawLine.trim();

        String matchValue =
                getValue(
                        line,
                        "MATCH"
                );

        if (!matchValue.isBlank()) {

            try {

                match =
                        Integer.parseInt(
                                matchValue.replaceAll(
                                        "[^0-9]",
                                        ""
                                )
                        );

            }

            catch (Exception ignored) {}

        }

        String missingValue =
                getValue(
                        line,
                        "MISSING"
                );

        if (!missingValue.isBlank()) {

            missingSkills =
                    Arrays.stream(
                            missingValue.split(",")
                    )
                    .map(String::trim)
                    .filter(skill -> !skill.isBlank())
                    .toList();

        }

        String priorityValue =
                getValue(
                        line,
                        "PRIORITY"
                );

        if (!priorityValue.isBlank()) {

            prioritySkills =
                    Arrays.stream(
                            priorityValue.split(",")
                    )
                    .map(String::trim)
                    .filter(skill -> !skill.isBlank())
                    .toList();

        }

        String coreValue =
                getValue(
                        line,
                        "CORE"
                );

        if (!coreValue.isBlank()) {

            coreSkills =
                    Arrays.stream(
                            coreValue.split(",")
                    )
                    .map(String::trim)
                    .filter(skill -> !skill.isBlank())
                    .toList();

        }


        String currentStageValue =
        getValue(
                line,
                "CURRENT_STAGE"
        );

if (!currentStageValue.isBlank()) {

    currentStage =
            currentStageValue;

}

String careerPositionValue =
        getValue(
                line,
                "CAREER_POSITION"
        );

if (!careerPositionValue.isBlank()) {

    careerPosition =
            careerPositionValue;

}

String timeValue =
        getValue(
                line,
                "TIME_TO_JOB_READY"
        );

if (!timeValue.isBlank()) {

    timeToJobReady =
            timeValue;

}

String learningOrderValue =
        getValue(
                line,
                "LEARNING_ORDER"
        );

if (!learningOrderValue.isBlank()) {

    learningOrder =
            Arrays.stream(
                    learningOrderValue.split(",")
            )
            .map(String::trim)
            .filter(s -> !s.isBlank())
            .toList();

}

String insightsValue =
        getValue(
                line,
                "TOP_INSIGHTS"
        );

if (!insightsValue.isBlank()) {

    topInsights =
            Arrays.stream(
                    insightsValue.split(",")
            )
            .map(String::trim)
            .filter(s -> !s.isBlank())
            .toList();

}

String focusValue =
        getValue(
                line,
                "FOCUS_NOW"
        );

if (!focusValue.isBlank()) {

    focusNow =
            Arrays.stream(
                    focusValue.split(",")
            )
            .map(String::trim)
            .filter(s -> !s.isBlank())
            .toList();

}

String employerValue =
        getValue(
                line,
                "EMPLOYER_EXPECTATIONS"
        );

if (!employerValue.isBlank()) {

    employerExpectations =
            Arrays.stream(
                    employerValue.split(",")
            )
            .map(String::trim)
            .filter(s -> !s.isBlank())
            .toList();

}

String mistakesValue =
        getValue(
                line,
                "COMMON_MISTAKES"
        );

if (!mistakesValue.isBlank()) {

    commonMistakes =
            Arrays.stream(
                    mistakesValue.split(",")
            )
            .map(String::trim)
            .filter(s -> !s.isBlank())
            .toList();

}

String adviceValue =
        getValue(
                line,
                "INDUSTRY_ADVICE"
        );

if (!adviceValue.isBlank()) {

    industryAdvice =
            Arrays.stream(
                    adviceValue.split(",")
            )
            .map(String::trim)
            .filter(s -> !s.isBlank())
            .toList();

}




        String advancedValue =
                getValue(
                        line,
                        "ADVANCED"
                );

        if (!advancedValue.isBlank()) {

            advancedSkills =
                    Arrays.stream(
                            advancedValue.split(",")
                    )
                    .map(String::trim)
                    .filter(skill -> !skill.isBlank())
                    .toList();

        }

        String projectValue =
                getValue(
                        line,
                        "PROJECTS"
                );

        if (!projectValue.isBlank()) {

            recommendedProjects =
                    Arrays.stream(
                            projectValue.split(",")
                    )
                    .map(String::trim)
                    .filter(skill -> !skill.isBlank())
                    .toList();

        }

        String certificationValue =
                getValue(
                        line,
                        "CERTIFICATIONS"
                );

        if (!certificationValue.isBlank()) {

            recommendedCertifications =
                    Arrays.stream(
                            certificationValue.split(",")
                    )
                    .map(String::trim)
                    .filter(skill -> !skill.isBlank())
                    .toList();

        }

        String resourceValue =
                getValue(
                        line,
                        "RESOURCES"
                );

        if (!resourceValue.isBlank()) {

            resources =
                    Arrays.stream(
                            resourceValue.split(",")
                    )
                    .map(String::trim)
                    .filter(skill -> !skill.isBlank())
                    .toList();

        }

    }

    System.out.println("========== Parsed Skill Gap ==========");

    System.out.println("Match : " + match);

    System.out.println("Core Skills : " + coreSkills);

    System.out.println("Priority Skills : " + prioritySkills);

    System.out.println("Missing Skills : " + missingSkills);

    System.out.println("Projects : " + recommendedProjects);

    System.out.println("Certifications : " + recommendedCertifications);

    System.out.println("Resources : " + resources);

    System.out.println("======================================");

}

catch (Exception e) {

    e.printStackTrace();

}

    profile.setSkillGapCompleted(true);

    profile.setCareerReadiness(
            calculateReadiness(profile)
    );

    profile.setCurrentStage(
            "SKILL GAP COMPLETED"
    );

profile.setLatestMissingSkills(
        missingSkills
);

profile.setLatestPrioritySkills(
        prioritySkills
);

System.out.println(
        "Saving missing skills: "
                + missingSkills
);

    studentProfileRepository
            .save(profile);

SkillGapAnalysis analysis = mapToAnalysis(

        email,

        profile,

        profileHash,

        match,

        currentStage,

        careerPosition,

        timeToJobReady,

        learningOrder,

        topInsights,

        focusNow,

        missingSkills,

        prioritySkills,

        coreSkills,

        advancedSkills,

        recommendedProjects,

        recommendedCertifications,

        resources,

        employerExpectations,

        commonMistakes,

        industryAdvice,

        resumeUploaded

);

skillGapAnalysisRepository.save(analysis);

   return SkillGapResponse.builder()

        .targetRole(
                profile.getDreamRole()
        )

        .currentSkills(
                profile.getSkills() == null
                        ? List.of()
                        : profile.getSkills()
        )

        .missingSkills(
                missingSkills
        )

        .prioritySkills(
                prioritySkills
        )

        .coreSkills(
                coreSkills
        )

        .advancedSkills(
                advancedSkills
        )

        .skillMatchPercentage(
                match
        )

        .readinessScore(
                match
        )

        .careerPosition(
                careerPosition
        )

        .currentStage(
                currentStage
        )

        .timeToJobReady(
                timeToJobReady
        )

        .learningOrder(
                learningOrder
        )

        .topInsights(
                topInsights
        )

        .focusNow(
                focusNow
        )

        .recommendedProjects(
                recommendedProjects
        )

        .recommendedCertifications(
                recommendedCertifications
        )

        .recommendedResources(
                resources
        )

        .employerExpectations(
                employerExpectations
        )

        .commonMistakes(
                commonMistakes
        )

        .industryAdvice(
                industryAdvice
        )

        .resumeConsidered(
                resumeUploaded
        )

        .build();
}



private String generateProfileHash(String data) {

    try {

        MessageDigest digest =
                MessageDigest.getInstance("SHA-256");

        byte[] hash =
                digest.digest(
                        data.getBytes(StandardCharsets.UTF_8)
                );

        StringBuilder builder =
                new StringBuilder();

        for (byte b : hash) {

            builder.append(
                    String.format("%02x", b)
            );

        }

        return builder.toString();

    }

    catch (NoSuchAlgorithmException e) {

        throw new RuntimeException(e);

    }

}

private SkillGapResponse mapToResponse(
        SkillGapAnalysis analysis
) {

    return SkillGapResponse.builder()

            .targetRole(
                    analysis.getTargetRole()
            )

            .currentSkills(
                    analysis.getCurrentSkills()
            )

            .missingSkills(
                    analysis.getMissingSkills()
            )

            .prioritySkills(
                    analysis.getPrioritySkills()
            )

            .skillMatchPercentage(
                    analysis.getSkillMatchPercentage()
            )

            .readinessScore(
                    analysis.getReadinessScore()
            )
            .recommendedResources(
                    analysis.getRecommendedResources()
            )
            

            .advancedSkills(
                    analysis.getAdvancedSkills()
            )

            .recommendedProjects(
                    analysis.getRecommendedProjects()
            )

            .recommendedCertifications(
                    analysis.getRecommendedCertifications()
            )

           
            .currentStage(
        analysis.getCurrentStage()
)

.careerPosition(
        analysis.getCareerPosition()
)

.timeToJobReady(
        analysis.getTimeToJobReady()
)

.learningOrder(
        analysis.getLearningOrder()
)

.topInsights(
        analysis.getTopInsights()
)

.focusNow(
        analysis.getFocusNow()
)

.employerExpectations(
        analysis.getEmployerExpectations()
)

.commonMistakes(
        analysis.getCommonMistakes()
)

.industryAdvice(
        analysis.getIndustryAdvice()
)
            .resumeConsidered(
                    analysis.getResumeConsidered()
            )
            

            .build();

}

private SkillGapAnalysis mapToAnalysis(

        String email,

        StudentProfile profile,

        String profileHash,

        Integer match,

        String currentStage,

        String careerPosition,

        String timeToJobReady,

        List<String> learningOrder,

        List<String> topInsights,

        List<String> focusNow,

        List<String> missingSkills,

        List<String> prioritySkills,

        List<String> coreSkills,

        List<String> advancedSkills,

        List<String> recommendedProjects,

        List<String> recommendedCertifications,

        List<String> resources,

        List<String> employerExpectations,

        List<String> commonMistakes,

        List<String> industryAdvice,

        Boolean resumeUploaded
) {

  return SkillGapAnalysis.builder()

    .email(email)

    .targetRole(profile.getDreamRole())

    .currentSkills(
        profile.getSkills() == null
                ? List.of()
                : profile.getSkills()
    )

    .skillMatchPercentage(match)

    .readinessScore(match)

    .currentStage(currentStage)

    .careerPosition(careerPosition)

    .timeToJobReady(timeToJobReady)

    .learningOrder(learningOrder)

    .topInsights(topInsights)

    .focusNow(focusNow)

    .missingSkills(missingSkills == null ? List.of() : missingSkills)

    .prioritySkills(prioritySkills == null ? List.of() : prioritySkills)

    .coreSkills(coreSkills == null ? List.of() : coreSkills)

    .advancedSkills(advancedSkills == null ? List.of() : advancedSkills)

    .recommendedProjects(recommendedProjects)

    .recommendedCertifications(recommendedCertifications)

    .recommendedResources(resources)

    .employerExpectations(employerExpectations)

    .commonMistakes(commonMistakes)

    .industryAdvice(industryAdvice)

    .resumeConsidered(resumeUploaded)

    .profileHash(profileHash)

    .generatedAt(java.time.LocalDateTime.now())

    .build();
}

private String getValue(
        String line,
        String key
) {

    if (line == null) {

        return "";

    }

    line = line.trim();

    int equalsIndex =
            line.indexOf("=");

    if (equalsIndex == -1) {

        return "";

    }

    String parsedKey =
            line.substring(
                    0,
                    equalsIndex
            ).trim();

    if (
            parsedKey.equalsIgnoreCase(
                    key
            )
    ) {

        return line.substring(
                equalsIndex + 1
        ).trim();

    }

    return "";

}

}