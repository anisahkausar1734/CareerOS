import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import axios from "axios";
import Navbar from "../components/Navbar";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend
} from "recharts";

function AdminDashboardPage() {

  const [data, setData] = useState(null);
  const role =
  localStorage.getItem("role");

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {

    try {

      const response =
        await axios.get(
          "http://localhost:8080/api/admin/dashboard"
        );

      setData(response.data);

    } catch (error) {

      console.log(error);
    }
  };
if (role !== "ADMIN") {

  return (
    <Navigate
      to="/dashboard"
      replace
    />
  );
}
  if (!data) {

    return (
      <h2 className="text-center mt-10">
        Loading...
      </h2>
    );
  }
return (
  <>
    <Navbar />

    <div className="p-8 bg-gray-100 min-h-screen">

      <div className="max-w-7xl mx-auto">

        <h1 className="text-3xl font-bold mb-6">
          Admin Dashboard
        </h1>

        {/* Stats Cards */}

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">

          <div className="bg-blue-100 p-6 rounded-xl shadow">
            <h2>Total Users</h2>
            <p className="text-3xl font-bold">
              {data.totalUsers}
            </p>
          </div>

          <div className="bg-green-100 p-6 rounded-xl shadow">
            <h2>Average ATS Score</h2>
            <p className="text-3xl font-bold">
              {Math.round(data.averageATSScore)}
            </p>
          </div>

          <div className="bg-purple-100 p-6 rounded-xl shadow">
            <h2>GitHub Profiles</h2>
            <p className="text-3xl font-bold">
              {data.usersWithGithub}
            </p>
          </div>

          <div className="bg-yellow-100 p-6 rounded-xl shadow">
            <h2>Dream Companies</h2>
            <p className="text-3xl font-bold">
              {data.usersWithDreamCompany}
            </p>
          </div>

        </div>

        {/* Charts */}

        <div className="grid lg:grid-cols-2 gap-6">

          {/* Role Distribution Pie Chart */}

          <div className="bg-white p-6 rounded-xl shadow">

            <h2 className="text-xl font-bold mb-4">
              Role Distribution
            </h2>

            <ResponsiveContainer
              width="100%"
              height={300}
            >
              <PieChart>

                <Pie
                  data={
                    Object.entries(
                      data.roleDistribution || {}
                    ).map(
                      ([role, count]) => ({
                        name: role,
                        value: count
                      })
                    )
                  }
                  dataKey="value"
                  nameKey="name"
                  outerRadius={100}
                  label
                >

                  {Object.entries(
                    data.roleDistribution || {}
                  ).map((_, index) => (

                    <Cell
                      key={index}
                      fill={
                        [
                          "#3B82F6",
                          "#10B981",
                          "#8B5CF6",
                          "#F59E0B",
                          "#EF4444",
                          "#06B6D4"
                        ][index % 6]
                      }
                    />

                  ))}

                </Pie>

                <Tooltip />

              </PieChart>
            </ResponsiveContainer>

          </div>

          {/* Profile Completion Bar Chart */}

          <div className="bg-white p-6 rounded-xl shadow">

            <h2 className="text-xl font-bold mb-4">
              Profile Completion
            </h2>

            <ResponsiveContainer
              width="100%"
              height={300}
            >

              <BarChart
                data={[
                  {
                    name: "GitHub",
                    value:
                      data.usersWithGithub
                  },
                  {
                    name: "LinkedIn",
                    value:
                      data.usersWithLinkedin
                  },
                  {
                    name: "Dream Company",
                    value:
                      data.usersWithDreamCompany
                  }
                ]}
              >

                <CartesianGrid strokeDasharray="3 3" />

                <XAxis dataKey="name" />

                <YAxis />

                <Tooltip />

                <Legend />

                <Bar
                  dataKey="value"
                  fill="#3B82F6"
                />

              </BarChart>

            </ResponsiveContainer>

          </div>

        </div>

      </div>

    </div>
  </>
);
}

export default AdminDashboardPage;