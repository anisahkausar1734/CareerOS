import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

import Sidebar from "../components/Sidebar";
import Topbar from "../components/Topbar";
import ScoreCard from "../components/ScoreCard";

function DashboardPage() {

 const loadDashboardData = async () => {

    try {

     

setAtsScore(
  resumeResponse.data.atsScore || 0
);

      const internshipResponse =
        await axios.get(
          `http://localhost:8080/api/internship/${email}`
        );

      setInternshipScore(
        internshipResponse.data.readinessScore || 0
      );

const profileResponse =
  await axios.get(
    `http://localhost:8080/api/student-profile/${email}`
  );

setProfile(
  profileResponse.data
);

     const resumeResponse =
  await axios.get(
    `http://localhost:8080/api/resume-analysis/cached/${email}`
  );

      setResumeScore(
        resumeResponse.data.resumeScore || 0
      );


      const roadmapResponse =
  await axios.get(
    `http://localhost:8080/api/roadmap/cached/${email}`
  );

setRoadmap(
  roadmapResponse.data
);

const projectResponse =
  await axios.get(
    `http://localhost:8080/api/projects/intelligence/${email}`
  );

setProjectIntel(
  projectResponse.data
);

    } catch (error) {

      console.log(error);

    }

  };







  const fullName =
    localStorage.getItem("fullName");

  const email =
    localStorage.getItem("email");

  const [atsScore, setAtsScore] =
    useState(0);

    const [roadmap, setRoadmap] =
  useState(null);

  const [projectIntel, setProjectIntel] =
  useState(null);

  const [internshipScore,
    setInternshipScore] =
    useState(0);

  const [resumeScore,
    setResumeScore] =
    useState(0);

  const [profile,
  setProfile] =
  useState(null);  

  useEffect(() => {
    loadDashboardData();
  }, []);

 

const getNextStep = () => {

  if (!profile) {
    return null;
  }

  if(
  roadmap?.nextAction
)
{
  return {
    title:
      roadmap.nextAction,
    route:
      "/resources"
  };
}

  if (!profile.skillGapCompleted) {

    return {
      title:
        "Complete Skill Gap Analysis",
      route:
        "/skill-gap"
    };

  }

  if (!profile.roadmapCompleted) {

    return {
      title:
        "Generate Career Roadmap",
      route:
        "/roadmap"
    };

  }

  if (!profile.resumeCompleted) {

    return {
      title:
        "Upload Resume",
      route:
        "/resume"
    };

  }

  if (!profile.interviewCompleted) {

    return {
      title:
        "Start Mock Interview",
      route:
        "/interview"
    };

  }

  return {

    title:
      "Apply To Jobs",

    route:
      "/jobs"

  };

};

const nextStep =
  getNextStep();



const getStrongestArea = () => {

 const scores = [

  {
    name: "Resume",
    score: resumeScore
  },

  {
    name: "ATS",
    score: atsScore
  },

  {
    name: "Internship",
    score: internshipScore
  },

  {
    name: "Projects",
    score:
      projectIntel?.overallProjectScore || 0
  },

  {
    name: "Career",
    score:
      profile?.careerReadiness || 0
  }

];

  return scores.sort(
    (a,b) =>
      b.score - a.score
  )[0]?.name;
};

  return (

    <>
      <Sidebar />

      <div
        className="
          ml-72
          min-h-screen
          bg-[#F5F3F8]
        "
      >

        <Topbar />

        <div className="p-8">


<div
  className="
    bg-gradient-to-r
    from-[#7367F0]
    to-[#9D8DFF]
    text-white
    rounded-3xl
    p-8
    mb-8
  "
>

  <p
    className="
      uppercase
      text-sm
      tracking-wider
      text-white/80
      mb-2
    "
  >
    Career Command Center
  </p>

  <h1
    className="
      text-4xl
      font-bold
      mb-3
    "
  >
    Welcome Back, {profile?.fullName} 👋
  </h1>

  <div
  className="
    mt-6
  "
>

  <div
    className="
      flex
      justify-between
      text-sm
      mb-2
    "
  >
    <span>Career Progress</span>

    <span>
      {profile?.careerReadiness}%
    </span>
  </div>

  <div
    className="
      bg-white/20
      h-3
      rounded-full
      overflow-hidden
    "
  >

    <div
      className="
        bg-white
        h-full
      "
      style={{
        width:
          `${profile?.careerReadiness || 0}%`
      }}
    />

  </div>

</div>

  <p
    className="
      text-white/90
      mb-6
    "
  >
    Your goal is to become a
    {` ${profile?.dreamRole}`}.
    Here's what you should focus on next.
  </p>



  <div
    className="
      flex
      flex-wrap
      gap-4
    "
  >

    <div
  className="
    bg-white/20
    px-4
    py-2
    rounded-xl
  "
>
  📈 {
    Math.round(
      (
        [
          profile?.skillGapCompleted,
          profile?.roadmapCompleted,
          profile?.resumeCompleted,
          profile?.interviewCompleted,
          profile?.jobsCompleted
        ].filter(Boolean).length
        / 5
      ) * 100
    )
  }% Complete
</div>

    <div className="bg-white/20 px-4 py-2 rounded-xl">
      🎯 {profile?.dreamRole}
    </div>

    <div className="bg-white/20 px-4 py-2 rounded-xl">
      🚀 {profile?.careerReadiness}% Ready
    </div>

    <div className="bg-white/20 px-4 py-2 rounded-xl">
      📍 {profile?.currentStage?.replaceAll("_"," ")}
    </div>

  </div>

</div>




<div
  className="
    bg-white
    rounded-3xl
    border
    border-[#E8E6EF]
    p-6
    mb-8
  "
>

  <div
    className="
      flex
      justify-between
      items-center
    "
  >

    <div>

      <h2
        className="
          text-xl
          font-bold
        "
      >
        Career Health
      </h2>

      <p
        className="
          text-gray-500
          mt-2
        "
      >
        Overall platform assessment
      </p>

    </div>

    <div
      className={`
        px-4
        py-2
        rounded-xl
        font-semibold
        ${
          profile?.careerReadiness >= 80
            ? "bg-green-100 text-green-700"
            : profile?.careerReadiness >= 60
            ? "bg-yellow-100 text-yellow-700"
            : "bg-red-100 text-red-700"
        }
      `}
    >
      {
        profile?.careerReadiness >= 80
          ? "Excellent"
          : profile?.careerReadiness >= 60
          ? "Good"
          : "Needs Attention"
      }
    </div>

  </div>

</div>


<div
  className="
    bg-white
    rounded-3xl
    border
    border-[#E8E6EF]
    p-8
    mb-8
  "
>

  <h2
    className="
      text-2xl
      font-bold
      mb-6
    "
  >
    📊 Career Insights
  </h2>

  <div
    className="
      grid
      md:grid-cols-3
      gap-6
    "
  >

    <div>
      <p className="text-gray-500">
        Strongest Area
      </p>

      <h3 className="font-bold mt-2">
        {getStrongestArea()}
      </h3>
    </div>

    <div>
      <p className="text-gray-500">
        Biggest Gap
      </p>

      <h3 className="font-bold mt-2">
        {roadmap?.topPrioritySkills?.[0]}
      </h3>
    </div>

    <div>
      <p className="text-gray-500">
        Recommended Focus
      </p>

      <h3 className="font-bold mt-2">
        {roadmap?.nextAction}
      </h3>
    </div>

  </div>

</div>


<div
  className="
    bg-white
    rounded-3xl
    border
    border-[#E8E6EF]
    p-8
    mb-8
  "
>

  <h2
    className="
      text-2xl
      font-bold
      mb-6
    "
  >
    🚀 Project Intelligence
  </h2>

  <div
    className="
      grid
      md:grid-cols-4
      gap-4
    "
  >

    <div>
      <p className="text-gray-500">
        Best Project
      </p>

      <h3 className="font-bold mt-2">
        {projectIntel?.bestProject}
      </h3>
    </div>

    <div>
      <p className="text-gray-500">
        Engineering
      </p>

      <h3 className="font-bold mt-2">
        {projectIntel?.averageEngineeringQuality}%
      </h3>
    </div>

    <div>
      <p className="text-gray-500">
        Role Alignment
      </p>

      <h3 className="font-bold mt-2">
        {projectIntel?.averageRoleAlignment}%
      </h3>
    </div>

    <div>
      <p className="text-gray-500">
        Production
      </p>

      <h3 className="font-bold mt-2">
        {projectIntel?.averageProductionReadiness}%
      </h3>
    </div>

  </div>

</div>


          <div
  className="
    bg-white
    rounded-2xl
    border
    border-[#E8E6EF]
    p-6
    mb-8
  "
>

  <div
  className="
    flex
    justify-between
    items-center
  "
>

  <div>

    <p
      className="
        text-sm
        text-[#7367F0]
        uppercase
        font-semibold
        mb-2
      "
    >
      Next Best Action
    </p>

    <h2
      className="
        text-2xl
        font-bold
      "
    >
      {nextStep?.title}
    </h2>

    <p
      className="
        text-gray-500
        mt-2
      "
    >
      Completing this step moves you closer
      to internship and job readiness.
    </p>

  </div>

  <Link
    to={nextStep?.route}
    className="
      bg-[#7367F0]
      text-white
      px-6
      py-3
      rounded-xl
    "
  >
    Continue →
  </Link>

</div>

 <div className="space-y-5">

  {[
    {
      completed: true,
      title: "Profile Setup"
    },
    {
      completed:
        profile?.skillGapCompleted,
      title:
        "Skill Gap Analysis"
    },
    {
      completed:
        profile?.roadmapCompleted,
      title:
        "Career Roadmap"
    },
    {
      completed:
        profile?.resumeCompleted,
      title:
        "Resume Analysis"
    },
    {
      completed:
        profile?.interviewCompleted,
      title:
        "Mock Interview"
    },
    {
      completed:
        profile?.jobsCompleted,
      title:
        "Job Applications"
    }
  ].map(
    (
      step,
      index
    ) => (

      <div
        key={index}
        className="
          flex
          items-center
          gap-4
        "
      >

        <div
          className={`
            w-10
            h-10
            rounded-full
            flex
            items-center
            justify-center
            font-bold
            ${
              step.completed
                ? "bg-green-100 text-green-600"
                : "bg-[#F5F3F8] text-gray-400"
            }
          `}
        >
          {step.completed ? "✓" : index + 1}
        </div>

        <div>

          <h3
            className="
              font-semibold
            "
          >
            {step.title}
          </h3>

          <p
            className="
              text-sm
              text-gray-500
            "
          >
            {
              step.completed
                ? "Completed"
                : "Pending"
            }
          </p>

        </div>

      </div>

    )
  )}

</div>

</div>



          {/* Stats */}

          <div
            className="
              grid
             grid-cols-1
md:grid-cols-2
lg:grid-cols-5
              gap-6
              mb-10
            "
          >

            <ScoreCard
              title="ATS Score"
              score={atsScore}
            />
<ScoreCard
  title="Career Readiness"
  score={profile?.careerReadiness || 0}
/>

<StatCard
  title="Project Score"
  value={`${projectIntel?.overallProjectScore || 0}%`}
/>

<ScoreCard
  title="Job Readiness"
  score={resumeScore}
/>


            <ScoreCard
              title="Internship Readiness"
              score={internshipScore}
            />

            <ScoreCard
              title="Resume Score"
              score={resumeScore}
            />

          </div>

          //QUICK ACTIONS//

<div
  className="
    bg-white
    rounded-3xl
    border
    border-[#E8E6EF]
    p-8
    mb-8
  "
>

  <h2
    className="
      text-2xl
      font-bold
      mb-6
    "
  >
    Career Journey
  </h2>

  <div className="space-y-4">

    <div>✅ Profile Setup</div>

    <div>
      {profile?.skillGapCompleted
        ? "✅ Skill Gap Analysis"
        : "⭕ Skill Gap Analysis"}
    </div>

    <div>
      {profile?.roadmapCompleted
        ? "✅ Career Roadmap"
        : "⭕ Career Roadmap"}
    </div>

    <div>
      {profile?.resumeCompleted
        ? "✅ Resume Analysis"
        : "⭕ Resume Analysis"}
    </div>

    <div>
      {profile?.interviewCompleted
        ? "✅ Mock Interview"
        : "⭕ Mock Interview"}
    </div>

    <div>
      {profile?.jobsCompleted
        ? "✅ Job Applications"
        : "⭕ Job Applications"}
    </div>

  </div>

</div>



<div
  className="
    bg-white
    rounded-3xl
    border
    border-[#E8E6EF]
    p-8
    mb-8
  "
>

  <h2
    className="
      text-2xl
      font-bold
      mb-6
    "
  >
    🎯 Priority Skill Gaps
  </h2>

  <div
    className="
      grid
      md:grid-cols-3
      gap-4
    "
  >

    {roadmap?.topPrioritySkills?.length > 0 ? (

  roadmap.topPrioritySkills.map(
    (skill,index) => (

      <Link
        key={index}
        to="/resources"
        className="
          bg-[#F5F3F8]
          rounded-2xl
          p-5
          block
          hover:border
          hover:border-[#7367F0]
          transition
        "
      >

        <h3
          className="
            font-semibold
          "
        >
          {skill}
        </h3>

        <p
          className="
            text-sm
            text-gray-500
            mt-2
          "
        >
          Recommended by CareerOS
        </p>

      </Link>

    )
  )

) : (

  <div
    className="
      col-span-full
      text-center
      py-10
      text-gray-500
    "
  >
    🎉 No skill gaps found.
    You're on track!
  </div>

)}

  </div>

</div>




<div
  className="
    bg-white
    rounded-3xl
    border
    border-[#E8E6EF]
    p-8
    mb-8
  "
>

  <h2
    className="
      text-2xl
      font-bold
      mb-6
    "
  >
    🚀 Recommended Projects
  </h2>

  <div
    className="
      grid
      md:grid-cols-3
      gap-4
    "
  >

  {roadmap?.recommendedProjects?.length > 0 ? (

  roadmap.recommendedProjects.map(
    (project,index) => (

      <Link
        to="/projects"
        key={index}
        className="
          bg-[#F5F3F8]
          rounded-2xl
          p-5
          block
          hover:border
          hover:border-[#7367F0]
          transition
        "
      >

        <h3
          className="
            font-semibold
          "
        >
          {project}
        </h3>

        <p
          className="
            text-sm
            text-gray-500
            mt-2
          "
        >
          High Impact Project
        </p>

        <p
          className="
            text-sm
            text-gray-500
            mt-2
          "
        >
          Recommended for {profile?.dreamRole}
        </p>

        <div
          className="
            mt-3
            inline-block
            bg-green-100
            text-green-700
            px-3
            py-1
            rounded-lg
            text-sm
          "
        >
          High Resume Impact
        </div>

      </Link>

    )
  )

) : (

  <div
    className="
      col-span-full
      text-center
      py-10
      text-gray-500
    "
  >
    🚀 No project recommendations available.
  </div>

)}
  </div>

</div>




<div
  className="
    grid
    md:grid-cols-2
    gap-6
    mb-8
  "
>
<div
  className="
    bg-white
    rounded-3xl
    border
    border-[#E8E6EF]
    p-8
  "
>

  <h2
    className="
      text-xl
      font-bold
      mb-4
    "
  >
    💼 Internship Readiness
  </h2>

  <h1
    className="
      text-5xl
      font-bold
      text-[#7367F0]
    "
  >
    {internshipScore}%
  </h1>

  <p
    className="
      mt-4
      text-gray-500
    "
  >
    Continue improving your skills,
    projects and resume.
  </p>

</div>

<div
  className="
    bg-white
    rounded-3xl
    border
    border-[#E8E6EF]
    p-8
  "
>

  <h2
    className="
      text-xl
      font-bold
      mb-4
    "
  >
    🚀 Career Readiness
  </h2>

  <h1
    className="
      text-5xl
      font-bold
      text-[#7367F0]
    "
  >
    {profile?.careerReadiness}%
  </h1>

  <p
    className="
      mt-4
      text-gray-500
    "
  >
    Overall readiness based on your
    roadmap progress and profile.
  </p>

</div>

</div>



<div
  className="
    grid
    md:grid-cols-4
    gap-4
    mb-8
  "
>

  <div className="bg-white rounded-2xl p-5">
    <p className="text-gray-500">
      Target Role
    </p>

    <h3 className="font-bold mt-2">
      {profile?.dreamRole}
    </h3>
  </div>

  <div className="bg-white rounded-2xl p-5">
    <p className="text-gray-500">
      Current Stage
    </p>

    <h3 className="font-bold mt-2">
      {profile?.currentStage?.replaceAll("_"," ")}
    </h3>
  </div>

  <div className="bg-white rounded-2xl p-5">
    <p className="text-gray-500">
      Missing Skills
    </p>

    <h3 className="font-bold mt-2">
      {roadmap?.topPrioritySkills?.length || 0}
    </h3>
  </div>

  <div className="bg-white rounded-2xl p-5">
    <p className="text-gray-500">
      Recommended Projects
    </p>

    <h3 className="font-bold mt-2">
      {roadmap?.recommendedProjects?.length || 0}
    </h3>
  </div>

</div>



<div
  className="
    bg-white
    rounded-3xl
    border
    border-[#E8E6EF]
    p-8
    mb-8
  "
>

  <h2
    className="
      text-2xl
      font-bold
      mb-6
    "
  >
    ⚡ Quick Launch
  </h2>

  <div
    className="
      grid
      md:grid-cols-4
      gap-4
    "
  >

    <Link
      to="/roadmap"
      className="
        bg-[#F5F3F8]
        p-5
        rounded-2xl
      "
    >
      🗺️ Roadmap
    </Link>

    <Link
      to="/resources"
      className="
        bg-[#F5F3F8]
        p-5
        rounded-2xl
      "
    >
      📚 Learning
    </Link>

    <Link
      to="/mock-interview"
      className="
        bg-[#F5F3F8]
        p-5
        rounded-2xl
      "
    >
      🎤 Interview
    </Link>

    <Link
      to="/copilot"
      className="
        bg-[#F5F3F8]
        p-5
        rounded-2xl
      "
    >
      🤖 Copilot
    </Link>

  </div>

</div>

<div
  className="
    bg-gradient-to-r
    from-[#7367F0]
    to-[#9D8DFF]
    text-white
    rounded-3xl
    p-8
  "
>

  <p
    className="
      uppercase
      text-sm
      text-white/80
      mb-2
    "
  >
    AI Career Guidance
  </p>

  <h2
    className="
      text-3xl
      font-bold
      mb-3
    "
  >
    Need Help Deciding What To Do Next?
  </h2>

  <p
    className="
      text-white/90
      mb-6
    "
  >
    Ask CareerOS Copilot for personalized
    career recommendations.
  </p>

  <Link
    to="/copilot"
    className="
      bg-white
      text-[#7367F0]
      px-6
      py-3
      rounded-xl
      font-semibold
      inline-block
    "
  >
    Open Copilot →
  </Link>

</div>





        </div>

      </div>

    </>

  );

}

export default DashboardPage;
