import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import { useSearchParams } from "react-router-dom";

function LearningResourcesPage() {

const [searchParams] =
  useSearchParams();

const skill =
  searchParams.get("skill");

const [searchVideos, setSearchVideos] =
  useState([]);  

const [searchSkill, setSearchSkill] =
useState(skill || "");

const [searchResults, setSearchResults] =
useState(null);

const [data, setData] =
useState([]);


const [videos, setVideos] =
  useState({});

useEffect(() => {
loadResources();
}, []);

useEffect(() => {

  if(skill) {

    setSearchSkill(skill);

    axios
      .get(
        `http://localhost:8080/api/resources/search/${skill}`
      )
      .then(response => {

        setSearchResults(
          response.data
        );

      })
      .catch(console.log);

  }

}, [skill]);

const loadResources = async () => {


try {

  const email =
    localStorage.getItem("email");

 const response =
  await axios.get(
    `http://localhost:8080/api/resources/${email}`
  );

setData(response.data);

for (
  const resource of response.data
) {

  try {


    console.log(
  "TITLE = ",
  resource.title
);

console.log(
  "ENCODED = ",
  encodeURIComponent(
    resource.title
  )
);
    const videoResponse =
   await axios.get(
  `http://localhost:8080/api/youtube?skill=${encodeURIComponent(
    resource.title
  )}`
);
    setVideos(prev => ({
      ...prev,
      [resource.title.replace("Learn ", "")]:
        videoResponse.data
    }));

  } catch(error) {

    console.log(error);

  }

}

 

} catch (error) {

  console.log(error);

}


};

const searchResources = async () => {


if (!searchSkill.trim()) {
  return;
}

try {

    const response =
    await axios.get(
  `http://localhost:8080/api/resources/search/${encodeURIComponent(searchSkill)}`
  );

    setSearchResults(
      response.data
    );

    const videosResponse =
  await axios.get(
    `http://localhost:8080/api/youtube?skill=${encodeURIComponent(
      searchSkill
    )}`
  );

setSearchVideos(
  videosResponse.data
);

} catch (error) {

  console.log(error);

}


};

if (!data || data.length === 0) {


return (
  <h2 className="text-center mt-10">
    No Learning Resources Available
  </h2>
);


}

const getCategoryLabel = (category) => {

  switch(category) {

    case "ATS":
      return "📄 ATS Optimization";

    case "PROJECT":
      return "💻 Project Building";

    case "SKILL":
      return "🧠 Skill Development";

    case "INTERNSHIP":
      return "🎯 Internship Preparation";

    default:
      return category;

  }

};

return (


<>
  <div className="flex bg-[#F5F3F8] min-h-screen">

    <Sidebar />

    <main className="ml-72 flex-1 p-8 overflow-x-hidden">

      <div className="max-w-7xl mx-auto">

        {/* Hero */}

        <div
          className="
            bg-gradient-to-r
            from-[#7367F0]
            to-[#9D8DFF]
            text-white
            rounded-3xl
            p-8
            mb-8
          "
        >

          <p className="uppercase text-sm opacity-80">
            Career Learning Hub
          </p>

          <h1
            className="
              text-4xl
              font-bold
              mt-2
            "
          >
            📚 Learning Resources
          </h1>

          <p className="mt-3 opacity-90">
            Resources synchronized directly
            from your Career Roadmap.
          </p>

        </div>


        {
  skill && (

    <div
      className="
        bg-white
        rounded-3xl
        border
        border-[#E8E6EF]
        p-6
        mb-8
      "
    >

      <p
        className="
          uppercase
          text-sm
          text-[#7367F0]
          font-semibold
          mb-2
        "
      >
        Recommended Skill
      </p>

      <h2
        className="
          text-3xl
          font-bold
          mb-2
        "
      >
        🚀 Learn {skill}
      </h2>

      <p className="text-gray-600">
        CareerOS identified this as one of
        your priority skills. Explore the
        learning resources below to start
        improving your readiness score.
      </p>

    </div>

  )
}

        {/* Search */}

        <div
          className="
            bg-white
            rounded-3xl
            border
            border-[#E8E6EF]
            p-6
            mb-8
          "
        >

          <h2
            className="
              text-xl
              font-semibold
              mb-4
            "
          >
            🔍 Search Any Skill
          </h2>

          <div className="flex flex-col md:flex-row gap-3">

            <input
              type="text"
              value={searchSkill}
              onChange={(e) =>
                setSearchSkill(
                  e.target.value
                )
              }
              placeholder="TensorFlow, Docker, Spring Boot..."
              className="
                flex-1
                border
                p-3
                rounded-xl
              "
            />

            <button
              onClick={searchResources}
              className="
                bg-[#7367F0]
                text-white
                px-6
                py-3
                rounded-xl
              "
            >
              Search
            </button>

          </div>

        </div>

        {/* Search Results */}

        {
          searchResults && (

            <div
              className="
                bg-white
                rounded-3xl
                border
                border-[#E8E6EF]
                p-6
                mb-8
              "
            >

              <h2
                className="
                  text-xl
                  font-semibold
                  mb-4
                "
              >
                🎯 Search Results
              </h2>

              <div
                className="
                  grid
                  md:grid-cols-2
                  gap-4
                "
              >

                {searchResults.resources?.map(
                  (
                    resource,
                    index
                  ) => (

                    <div
                      key={index}
                      className="
                        p-4
                        rounded-xl
                        bg-blue-100
                      "
                    >
                      {resource}
                    </div>

                  )
                )}
</div>
                {
  searchVideos?.length > 0 && (

    <div className="mt-8">

      <h3
        className="
          text-xl
          font-semibold
          mb-4
        "
      >
        🎥 Recommended Videos
      </h3>

      <div
        className="
          grid
          md:grid-cols-2
          gap-4
        "
      >

        {
          searchVideos.map(
            (
              video,
              index
            ) => (

              <a
                key={index}
                href={video.videoUrl}
                target="_blank"
                rel="noreferrer"
                className="
                  bg-[#F5F3F8]
                  rounded-2xl
                  overflow-hidden
                  hover:shadow-lg
                  transition
                "
              >

                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="
                    w-full
                    h-48
                    object-cover
                  "
                />

                <div className="p-4">

                  <h4
                    className="
                      font-semibold
                    "
                  >
                    {video.title}
                  </h4>

                  <p
                    className="
                      text-sm
                      text-gray-500
                      mt-1
                    "
                  >
                    {video.channel}
                  </p>

                </div>

              </a>

            )
          )
        }

      </div>

    </div>

  )
}

              </div>


          )
        }

        {/* Roadmap Resource Cards */}

        <div className="space-y-6">

          {data.map(
            (step) => (

              <div
                key={step.phase}
                className="
                  bg-white
                  rounded-3xl
                  border
                  border-[#E8E6EF]
                  p-8
                "
              >

                <div
                  className="
                    flex
                    flex-wrap
                    gap-3
                    mb-4
                  "
                >

                  <span
                    className="
                      bg-[#7367F0]
                      text-white
                      px-3
                      py-1
                      rounded-lg
                      text-sm
                    "
                  >
{getCategoryLabel(step.category)}
                  </span>

                  <span
                    className={`
                      px-3
                      py-1
                      rounded-lg
                      text-sm
                      ${
                        step.priority === "HIGH"
                          ? "bg-red-100 text-red-600"
                          : step.priority === "MEDIUM"
                          ? "bg-yellow-100 text-yellow-700"
                          : "bg-green-100 text-green-700"
                      }
                    `}
                  >
                    {step.priority}
                  </span>

                </div>

              

                <div
                  className="
                    flex
                    justify-between
                    items-center
                    mb-4
                  "
                >

                  <h2
                    className="
                      text-2xl
                      font-bold
                    "
                  >
                    📍 Phase {step.phase}
                  </h2>

                  <span
                    className="
                      bg-[#F5F3F8]
                      px-4
                      py-2
                      rounded-xl
                    "
                  >
                    ⏳ {step.estimatedWeeks} Weeks
                  </span>

                </div>

                
                <h3
                  className="
                    text-xl
                    font-semibold
                    text-[#7367F0]
                    mb-3
                  "
                >
                  {step.title}
                </h3>

                <p
                  className="
                    text-gray-600
                    mb-5
                  "
                >
                  {step.description}
                </p>

                <div className="mb-4">

                  <span
                    className="
                      bg-green-100
                      text-green-700
                      px-4
                      py-2
                      rounded-xl
                      text-sm
                      font-semibold
                    "
                  >
                    🚀 {step.impact}
                  </span>

                </div>

               
                <p
                  className="
                    text-sm
                    text-gray-500
                    mb-5
                  "
                >
                  💡 {step.reason}
                </p>

                <h4
                  className="
                    font-semibold
                    mb-3
                  "
                >
                  📚 Recommended Resources
                </h4>

                <div
                  className="
                    flex
                    flex-wrap
                    gap-2
                  "
                >

                  {step.resources?.map(
                    (
                      resource,
                      index
                    ) => (

                      <span
                        key={index}
                        className="
                          bg-[#F5F3F8]
                          px-4
                          py-2
                          rounded-xl
                        "
                      >
                        {resource}
                      </span>

                    )
                  )}

                </div>

              

<h4
  className="
    font-semibold
    mt-6
    mb-3
  "
>
  🎬 Curated Learning Videos
</h4>

<div
  className="
    grid
    md:grid-cols-3
    gap-4
  "
>

{
  videos[step.title]?.length > 0 ? (

    videos[step.title]
      .slice(0, 3)
      .map((video, index) => (

        <a
          key={index}
          href={video.videoUrl}
          target="_blank"
          rel="noreferrer"
          className="
            border
            rounded-xl
            overflow-hidden
            hover:shadow-lg
            transition
            bg-white
          "
        >

          <img
            src={video.thumbnail}
            alt={video.title}
            className="
              w-full
              h-40
              object-cover
            "
          />

          <div className="p-4">

            <p
              className="
                font-semibold
                line-clamp-2
              "
            >
              {video.title}
            </p>

            <p
              className="
                text-sm
                text-gray-500
                mt-2
              "
            >
              {video.channel}
            </p>

          </div>

        </a>

      ))

  ) : (

   <div
  className="
    col-span-3
    text-center
    text-gray-400
    py-8
  "
>
  🎥 No curated videos found for this topic yet
</div>

  )
}

</div>

{
  videos[step.title]?.length > 0 && (

    <div
      className="
        mt-4
        text-right
      "
    >

      <a
        href={`https://www.youtube.com/results?search_query=${encodeURIComponent(step.title)}`}
        target="_blank"
        rel="noreferrer"
        className="
          text-[#7367F0]
          font-semibold
        "
      >
        View More Videos →
      </a>

    </div>

  )
}

              </div>

            )
          )}

        </div>

      </div>

    </main>

  </div>

</>

);

}

export default LearningResourcesPage;











