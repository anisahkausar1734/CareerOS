import { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function ProfileEditPage() { 

  const navigate = useNavigate();

  const email =
    localStorage.getItem("email");

  const [formData, setFormData] =
    useState({

      fullName:
        localStorage.getItem("fullName") || "",

      phoneNumber: "",

      collegeName: "",

      degree: "",

      branch: "",

      currentYear: "",

      graduationYear: "",

      dreamRole: "",

      skills: ""

    });

    const [loading, setLoading] =
    useState(true);

  const handleChange = (e) => {

    setFormData({
      ...formData,
      [e.target.name]:
        e.target.value
    });

  };

useEffect(() => {

    fetchProfile();

}, []);

const fetchProfile = async () => {

    try {

        const email =
                localStorage.getItem(
                        "email"
                );

        const response =
                await axios.get(
                        `http://localhost:8080/api/student-profile/${email}`
                );

        setFormData({

            fullName:
                response.data.fullName || "",

            phoneNumber:
                response.data.phoneNumber || "",

            collegeName:
                response.data.collegeName || "",

            degree:
                response.data.degree || "",

            branch:
                response.data.branch || "",

            currentYear:
                response.data.currentYear || "",

            graduationYear:
                response.data.graduationYear || "",

            dreamRole:
                response.data.dreamRole || "",

            skills:
                response.data.skills?.join(", ") || ""

        });

    } catch(error) {

        console.error(error);

    }

    finally {

        setLoading(false);
    }

};

  const handleSubmit = async (e) => {

    e.preventDefault();

    try {

      await axios.put(
  `http://localhost:8080/api/student-profile/${email}`,
  {
    email,

    fullName:
      formData.fullName,

    phoneNumber:
      formData.phoneNumber,

    collegeName:
      formData.collegeName,

    degree:
      formData.degree,

    branch:
      formData.branch,

    currentYear:
      formData.currentYear,

    graduationYear:
      Number(
        formData.graduationYear
      ),

    dreamRole:
      formData.dreamRole,

    skills:
  formData.skills
    .split(/[\n,]+/)
    .map(skill => skill.trim())
    .filter(skill => skill)
  }
);

alert(
  "Profile updated successfully"
);

navigate("/profile");

    } catch (error) {

      console.log(error);

      alert(
        "Failed to save profile"
      );

    }

  };

if(loading) {

    return (

        <div className="
            min-h-screen
            flex
            items-center
            justify-center
        ">

            <div className="
                text-2xl
                font-semibold
                text-indigo-600
            ">
                Loading Profile...
            </div>

        </div>

    );
}
  
  return (

    <div
      className="
        min-h-screen
bg-gradient-to-br
from-indigo-50
via-white
to-purple-50
        flex
        items-center
        justify-center
        p-8
      "
    >

      <div
        className="
          bg-white/90
backdrop-blur-md
w-full
max-w-5xl
rounded-[32px]
shadow-2xl
p-12
border
border-indigo-100
        "
      >

       <div className="flex items-center gap-4 mb-3">

    <div className="
        w-14
        h-14
        rounded-2xl
        bg-gradient-to-r
        from-indigo-600
        to-purple-600
        flex
        items-center
        justify-center
        text-white
        text-2xl
    ">
        ✏️
    </div>

    <div>

        <h1 className="
            text-5xl
            font-bold
            text-slate-800
        ">
            Edit Profile
        </h1>

        <p className="
            text-slate-500
            mt-1
        ">
            Update your academic and career information.
        </p>

    </div>

</div>
       

        <form
          onSubmit={handleSubmit}
          className="
            grid
            md:grid-cols-2
            gap-5
          "
        >


    <label className="
        block
        mb-2
        font-medium
        text-slate-700
    ">
        Full Name
    </label>
          <input
            type="text"
            name="fullName"
            placeholder="Full Name"
            value={formData.fullName}
            onChange={handleChange}
className="
    p-4
    rounded-2xl
    border
    border-slate-200
    bg-slate-50
    focus:bg-white
    focus:border-indigo-500
    focus:ring-4
    focus:ring-indigo-100
    outline-none
    transition
"
            required
          />

 <label className="
        block
        mb-2
        font-medium
        text-slate-700
    ">
        Phone Number
    </label>
          <input
            type="text"
            name="phoneNumber"
            placeholder="Phone Number"
            value={formData.phoneNumber}
            onChange={handleChange}
className="
    p-4
    rounded-2xl
    border
    border-slate-200
    bg-slate-50
    focus:bg-white
    focus:border-indigo-500
    focus:ring-4
    focus:ring-indigo-100
    outline-none
    transition
"            required
          />


 <label className="
        block
        mb-2
        font-medium
        text-slate-700
    ">
        College Name
    </label>
          <input
            type="text"
            name="collegeName"
            placeholder="College Name"
            value={formData.collegeName}
            onChange={handleChange}
className="
    p-4
    rounded-2xl
    border
    border-slate-200
    bg-slate-50
    focus:bg-white
    focus:border-indigo-500
    focus:ring-4
    focus:ring-indigo-100
    outline-none
    transition
"            required
          />
 <label className="
        block
        mb-2
        font-medium
        text-slate-700
    ">
        Degree
    </label>
          <input
            type="text"
            name="degree"
            placeholder="Degree"
            value={formData.degree}
            onChange={handleChange}
className="
    p-4
    rounded-2xl
    border
    border-slate-200
    bg-slate-50
    focus:bg-white
    focus:border-indigo-500
    focus:ring-4
    focus:ring-indigo-100
    outline-none
    transition
"            required
          />


 <label className="
        block
        mb-2
        font-medium
        text-slate-700
    ">
        Branch
    </label>
          <input
            type="text"
            name="branch"
            placeholder="Branch"
            value={formData.branch}
            onChange={handleChange}
className="
    p-4
    rounded-2xl
    border
    border-slate-200
    bg-slate-50
    focus:bg-white
    focus:border-indigo-500
    focus:ring-4
    focus:ring-indigo-100
    outline-none
    transition
"            required
          />
 <label className="
        block
        mb-2
        font-medium
        text-slate-700
    ">
        Current Year
    </label>
          <select
            name="currentYear"
            value={formData.currentYear}
            onChange={handleChange}
className="
    p-4
    rounded-2xl
    border
    border-slate-200
    bg-slate-50
    focus:bg-white
    focus:border-indigo-500
    focus:ring-4
    focus:ring-indigo-100
    outline-none
    transition
"            required
          >
            <option value="">
              Select Year
            </option>

            <option>
              1st Year
            </option>

            <option>
              2nd Year
            </option>

            <option>
              3rd Year
            </option>

            <option>
              4th Year
            </option>

          </select>

 <label className="
        block
        mb-2
        font-medium
        text-slate-700
    ">
        Graduation Year
    </label>
          <input
            type="number"
            name="graduationYear"
            placeholder="Graduation Year"
            value={formData.graduationYear}
            onChange={handleChange}
className="
    p-4
    rounded-2xl
    border
    border-slate-200
    bg-slate-50
    focus:bg-white
    focus:border-indigo-500
    focus:ring-4
    focus:ring-indigo-100
    outline-none
    transition
"            required
          />
 <label className="
        block
        mb-2
        font-medium
        text-slate-700
    ">
        Dream Role
    </label>
          <input
            type="text"
            name="dreamRole"
            placeholder="Dream Role"
            value={formData.dreamRole}
            onChange={handleChange}
className="
    p-4
    rounded-2xl
    border
    border-slate-200
    bg-slate-50
    focus:bg-white
    focus:border-indigo-500
    focus:ring-4
    focus:ring-indigo-100
    outline-none
    transition
"            required
          />

          <div className="md:col-span-2">

    <label
        className="
            block
            mb-2
            font-medium
            text-slate-700
        "
    >
        Skills
    </label>

    <textarea
        rows="4"
        name="skills"
        placeholder="Python, Java, React, Spring Boot..."
        value={formData.skills}
        onChange={handleChange}
        className="
            w-full
            p-4
            rounded-2xl
            border
            border-slate-200
            bg-slate-50
            focus:bg-white
            focus:border-indigo-500
            focus:ring-4
            focus:ring-indigo-100
            outline-none
            transition
        "
        required
    />

    <p className="text-sm text-slate-500 mt-2">
        Separate skills using commas.
    </p>

</div>
<div className="
    md:col-span-2
    flex
    gap-4
">

    <button
        type="button"
        onClick={() =>
            navigate("/profile")
        }
        className="
            w-1/3
            border
            border-slate-300
            py-4
            rounded-2xl
            font-semibold
            hover:bg-slate-100
        "
    >
        Cancel
    </button>

    <button
        type="submit"
        className="
            w-2/3
            bg-gradient-to-r
            from-indigo-600
            to-purple-600
            hover:from-indigo-700
            hover:to-purple-700
            text-white
            py-4
            rounded-2xl
            font-semibold
            text-lg
            shadow-lg
        "
    >
        Save Changes
    </button>

</div>

        </form>

      </div>

    </div>

  );

}

export default ProfileEditPage;