﻿import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";

function ProfilePage() {

    const [profile, setProfile] = useState(null);

    const email =
        localStorage.getItem("email");

    useEffect(() => {
        fetchProfile();
    }, []);

    const fetchProfile = async () => {

        try {

            const response =
                await axios.get(
                    `http://localhost:8080/api/student-profile/${email}`
                );

            setProfile(response.data);

        } catch (error) {

            console.error(error);
        }
    };

    if (!profile) {

        return (
            <div className="flex">
                <Sidebar />

                <div className="ml-72 p-8">
                    Loading...
                </div>
            </div>
        );
    }

    return (

<div className="min-h-screen bg-[#F7F7FB] flex">

    <Sidebar />

<div className="ml-[240px] w-[calc(100%-240px)] px-10 py-10">
        {/* ================= HEADER ================= */}

        <div
            className="
                flex
                items-start
                justify-between
                mb-10
            "
        >

            <div>

                <span
                    className="
                        inline-flex
                        items-center
                        px-4
                        py-2
                        rounded-full
                        bg-[#F4F2FF]
                        text-[#7367F0]
                        text-sm
                        font-medium
                        mb-5
                    "
                >
                    Career Profile
                </span>

                <h1
                    className="
                        text-4xl
                        font-bold
                        tracking-tight
                        text-slate-900
                    "
                >
                    My Profilesss
                </h1>

                <p
                    className="
                        mt-3
                        text-slate-500
                        text-lg
                        leading-8
                        max-w-2xl
                    "
                >
                    Manage your personal information, academic details
                    and career preferences that power your personalized
                    CareerOS journey.
                </p>

            </div>

            <button

                onClick={() =>
                    window.location.href="/profile/edit"
                }

                className="
                    bg-[#7367F0]
                    hover:bg-[#6658EC]
                    transition
                   

hover:shadow-md
                    text-white
                    rounded-2xl
                    px-6
                    py-3
                    font-medium
                    shadow-sm
                "
            >

                Edit Details

            </button>

        </div>



        {/* ================= PROFILE SUMMARY ================= */}

        <div
            className="
                bg-white
                border
                border-[#ECEAF5]
                rounded-[30px]
                p-8
                mb-8
            "
        >

           <div
    className="
        flex
        flex-col
        xl:flex-row
        justify-between
        gap-8
    "
>

                {/* Left */}

               {/* Left */}

<div
    className="
        flex
        items-center
        gap-5
        flex-1
    "
>
    <div
        className="
            w-20
            h-20
            rounded-full
            bg-[#7367F0]
            text-white
            flex
            items-center
            justify-center
            text-3xl
            font-semibold
        "
    >
        {profile.fullName?.charAt(0)?.toUpperCase()}
    </div>

    <div>
        <h2
            className="
                text-[32px]
                font-semibold
                text-slate-900
            "
        >
            {profile.fullName}
        </h2>

        <p
            className="
                mt-2
                text-slate-500
                text-lg
            "
        >
            {profile.dreamRole}
        </p>
    </div>
</div>


                {/* Right */}

                <div
                    className="
                        grid
                        grid-cols-2
                        gap-4
                       w-full xl:w-[420px]
                    "
                >

                    <SummaryCard
                        title="Career Readiness"
                        value={`${profile.careerReadiness ?? 0}%`}
                        valueColor="text-green-600"
                    />

                    <SummaryCard
                        title="Current Stage"
                        value={
                          profile.currentStage
    ? profile.currentStage
        .replaceAll("_"," ")
        .toLowerCase()
        .replace(/\b\w/g,c=>c.toUpperCase())
    : "Profile Completed"
                        }
                    />

                 <SummaryCard
    title="Resume Status"
    value={
       profile.resumeCompleted
            ? "Uploaded"
            : "Not Uploaded"
    }
    valueColor={
        profile.resumeCompleted
            ? "text-green-600"
            : "text-amber-600"
    }
/>

                    <SummaryCard
                        title="Skills"
                       value={`${profile.skills?.length ?? 0} Skills`}
                    />

                </div>

            </div>



            <div className="mt-8">

                <div
                    className="
                        flex
                        justify-between
                        text-sm
                        mb-3
                    "
                >

                    <span className="text-slate-500">

                      Career Progress

                    </span>

                    <span
                        className="
                            text-[#7367F0]
                            font-medium
                        "
                    >

                        {profile.careerReadiness ?? 0}%

                    </span>

                </div>

                <div
                    className="
                        h-3
                        rounded-full
                        bg-[#EEF0F5]
                        overflow-hidden
                    "
                >

                    <div

                        className="
                            h-full
                            rounded-full
                            bg-[#7367F0]
                        "

                        style={{

                            width:
                            `${profile.careerReadiness ?? 0}%`

                        }}

                    />

                </div>

<p
    className="
        mt-3
        text-sm
        text-slate-500
    "
>
    Complete more milestones to unlock
    personalized AI recommendations.
</p>

            </div>

        </div>

<div className="grid lg:grid-cols-2 gap-6 mb-8">

    {/* ================= PERSONAL INFORMATION ================= */}

    <div
        className="
            bg-white
            border
            border-[#ECEAF5]
            rounded-[28px]
            p-8
        "
    >

        <h3
            className="
                text-xl
                font-semibold
                text-slate-900
                mb-6
            "
        >
            Personal Information
        </h3>

        <div className="space-y-5">

            <InfoRow
                label="Full Name"
                value={profile.fullName}
            />

            <InfoRow
                label="Email"
                value={profile.email}
            />

            <InfoRow
                label="Phone Number"
                value={
                    profile.phoneNumber ||
                    "Not Added"
                }
            />

        </div>

    </div>



    {/* ================= ACADEMIC INFORMATION ================= */}

    <div
        className="
            bg-white
            border
            border-[#ECEAF5]
            rounded-[28px]
            p-8
        "
    >

        <h3
            className="
                text-xl
                font-semibold
                text-slate-900
                mb-6
            "
        >
            Academic Information
        </h3>

        <div className="space-y-5">

            <InfoRow
                label="College"
                value={profile.collegeName}
            />

            <InfoRow
                label="Degree"
                value={profile.degree}
            />

            <InfoRow
                label="Branch"
                value={profile.branch}
            />

            <InfoRow
                label="Current Year"
                value={profile.currentYear}
            />

            <InfoRow
                label="Graduation Year"
                value={profile.graduationYear}
            />

        </div>

    </div>

</div>




<div className="grid lg:grid-cols-2 gap-6 mb-8">

    {/* ================= CAREER PROFILE ================= */}

    <div
        className="
            bg-white
            border
            border-[#ECEAF5]
            rounded-[28px]
            p-8
        "
    >

        <h3
            className="
                text-xl
                font-semibold
                text-slate-900
                mb-6
            "
        >
            Career Profile
        </h3>

        <div className="space-y-6">

            <InfoRow
                label="Dream Role"
                value={profile.dreamRole}
            />

            <div>

                <p
                    className="
                        text-slate-500
                        mb-3
                    "
                >
                    Current Skills
                </p>

                <div className="flex flex-wrap gap-2">

                    {

                        profile.skills?.length > 0

                        ?

                        profile.skills.map(

                            (skill,index)=>(

                                <span

                                    key={index}

                                    className="
                                        px-3
                                        py-1.5
                                        rounded-full
                                        bg-[#F4F2FF]
                                        text-[#7367F0]
                                        text-sm
                                        font-medium
                                    "

                                >

                                    {skill}

                                </span>

                            )

                        )

                        :

                       <div
    className="
        rounded-xl
        bg-[#F8F9FC]
        border
        border-[#ECEAF5]
        px-4
        py-4
        text-slate-500
        text-sm
    "
>
    You're just getting started.

    CareerOS will guide you from the basics.
</div>

                    }

                </div>

            </div>

            <InfoRow

                label="Resume Status"

                value={

                    profile.resumeCompleted

                        ?

                        "Uploaded"

                        :

                        "Not Uploaded"

                }

            />

        </div>

    </div>





    {/* ================= CAREER JOURNEY ================= */}

    <div

        className="
            bg-white
            border
            border-[#ECEAF5]
            rounded-[28px]
            p-8
        "

    >

        <h3
            className="
                text-xl
                font-semibold
                text-slate-900
                mb-6
            "
        >

            Career Journey

        </h3>

        <div className="space-y-4">

            <JourneyRow

                title="Skill Gap Analysis"

                completed={profile.skillGapCompleted}

            />

            <JourneyRow

                title="Career Roadmap"

                completed={profile.roadmapCompleted}

            />

            <JourneyRow

                title="Resume Analysis"

                completed={profile.resumeCompleted}

            />

            <JourneyRow

                title="Mock Interview"

                completed={profile.interviewCompleted}

            />

            <JourneyRow

                title="Applications"

                completed={profile.jobsCompleted}

            />

        </div>

    </div>

</div>

</div>

);

}


function SummaryCard({

    title,

    value,

    valueColor="text-slate-900"

}){

    return(

        <div
            className="
                border
                border-[#ECEAF5]
                rounded-3xl
                p-4
            "
        >

            <p
                className="
                    text-sm
                    text-slate-500
                "
            >
                {title}
            </p>

            <h4
                className={`
                    mt-2
                    text-xl
                    font-semibold
                    ${valueColor}
                `}
            >
                {value}
            </h4>

        </div>

    );

}

function InfoRow({

    label,

    value

}){

    return(

        <div
            className="
                flex
                justify-between
                items-center
                py-3
                border-b
                border-[#F1F2F6]
                last:border-none
            "
        >

            <p
                className="
                    text-slate-500
                     w-40
                "
            >
                {label}
            </p>

           <p
    className="
        flex-1
        font-medium
        text-slate-900
        text-right
        break-words
    "
>
                {value || "Not Added"}
            </p>

        </div>

    );

}

function JourneyRow({

    title,

    completed

}){

    return(

        <div
            className="
                flex
                justify-between
                items-center
                border
                border-[#ECEAF5]
                rounded-2xl
                px-5
                py-4
            "
        >

           <div
    className="
        flex
        items-center
        gap-3
    "
>

    <div

        className={`

            w-3

            h-3

            rounded-full

            ${

                completed

                ?

                "bg-green-500"

                :

                "bg-slate-300"

            }

        `}

    />

    <p
        className="
            font-medium
            text-slate-900
        "
    >
        {title}
    </p>

</div>

            <span

                className={`
                   min-w-[95px]
text-center
                    px-3

                    py-1.5

                    rounded-full

                    text-xs

                    font-semibold

                    ${

                        completed

                        ?

                        "bg-green-100 text-green-700"

                        :

                        "bg-slate-100 text-slate-500"

                    }

                `}

            >

                {

                    completed

                    ?

                    "Completed"

                    :

                    "Start Now"

                }

          </span>

</div>

);

}

export default ProfilePage;