import { useEffect, useState } from "react";
import axios from "axios";

import Sidebar from "../components/Sidebar";
import Topbar from "../components/Topbar";

function ResumeCenterPage() {

  const [data, setData] =
  useState(null);

const [gapData, setGapData] =
  useState(null);

const [resume, setResume] =
  useState(null);

const [file, setFile] =
  useState(null);

const [loading, setLoading] =
  useState(true);

const [uploading, setUploading] =
  useState(false);

const [error, setError] =
  useState("");

const loadResume = async () => {

  try {

    const email =
      localStorage.getItem("email");

    const response =
      await axios.get(
        `http://localhost:8080/api/resumes/${email}`
      );

    setResume(
      response.data
    );

  } catch (error) {

    console.log(error);

  }

}; 

const uploadResume = async () => {

  if (!file) {

    alert("Please select a resume");

    return;
  }

  try {

    setUploading(true);

    const email =
      localStorage.getItem("email");

    const formData =
      new FormData();

    formData.append(
      "email",
      email
    );

    formData.append(
      "file",
      file
    );

    await axios.post(
      "http://localhost:8080/api/resumes/upload",
      formData,
      {
        headers: {
          "Content-Type":
            "multipart/form-data"
        }
      }
    );

    await loadResume();

    await loadResumeCenter();

    await loadResumeGap();

    alert(
      "Resume uploaded successfully"
    );

  } catch (error) {

    console.log(error);

    alert(
      "Upload failed"
    );

  } finally {

    setUploading(false);

  }

};

useEffect(() => {

  loadResume();
  loadResumeCenter();
  loadResumeGap();

}, []);  


  const loadResumeGap = async () => {

  try {

    const email =
      localStorage.getItem(
        "email"
      );

    const response =
      await axios.get(
        `http://localhost:8080/api/resume-gap/${email}`
      );

    setGapData(
      response.data
    );

  } catch (error) {

    console.log(error);

  }

};



  const loadResumeCenter = async () => {

    try {

      const email =
        localStorage.getItem(
          "email"
        );

      const response =
        await axios.get(
          `http://localhost:8080/api/resume-center/${email}`
        );

      setData(
        response.data
      );

    } catch (error) {

      console.log(error);

    } finally {

      setLoading(false);

    }

  };


const metrics = [
  {
    title: "Resume Score",
    value: data?.resumeScore
  },
  {
    title: "ATS Score",
    value: data?.atsScore
  },
  {
    title: "Role Alignment",
    value: data?.roleAlignmentScore
  },
  {
    title: "Skills Coverage",
    value: data?.skillsCoverageScore
  },
  {
    title: "Project Strength",
    value: data?.projectStrengthScore
  },
  {
    title: "Internship Readiness",
    value: data?.internshipReadiness
  },
  {
    title: "Job Readiness",
    value: data?.jobReadiness
  },
  {
    title: "Resume Match",
    value: gapData?.matchPercentage
  }
];

  if (loading) {

  return (
    <>
      <Sidebar />

      <div
        className="
          ml-72
          min-h-screen
          bg-[#F5F3F8]
          flex
          items-center
          justify-center
        "
      >
        <h2
          className="
            text-2xl
            font-semibold
            text-[#7367F0]
          "
        >
          Loading Resume Intelligence...
        </h2>
      </div>
    </>
  );

}

return (

  <>
    <Sidebar />

    <div
      className="
        ml-72
        min-h-screen
        bg-[#F5F3F8]
      "
    >


      <div className="p-8">

        {/* Header */}

      <div
  className="
    bg-gradient-to-r
    from-[#7367F0]
    to-[#9D8DFF]
    text-white
    rounded-3xl
    p-8
    mb-8
  "
>

  <p className="uppercase text-sm opacity-80">
    Resume Intelligence
  </p>

  <h1
    className="
      text-4xl
      font-bold
      mt-2
    "
  >
    📄 Resume Center
  </h1>

  <p className="mt-3 opacity-90">
    Analyze, optimize and track your resume
    for {data?.dreamRole}.
  </p>

  <div
    className="
      flex
      flex-wrap
      gap-4
      mt-6
    "
  >

    <div
      className="
        bg-white/20
        px-4
        py-2
        rounded-xl
      "
    >
      🎯 {data?.dreamRole}
    </div>

    <div
      className="
        bg-white/20
        px-4
        py-2
        rounded-xl
      "
    >
      📊 Resume Score: {data?.resumeScore || 0}%
    </div>

    <div
      className="
        bg-white/20
        px-4
        py-2
        rounded-xl
      "
    >
      🤖 ATS Score: {data?.atsScore || 0}%
    </div>

  </div>

</div>
        {/* Upload Resume */}

        <div
          className="
            bg-white
            rounded-3xl
            border
            border-[#E8E6EF]
            p-8
            mb-8
          "
        >

          <h2
            className="
              text-2xl
              font-semibold
              mb-6
            "
          >
            Upload Resume
          </h2>

          <input
            type="file"
            accept=".pdf,.doc,.docx"
            onChange={(e) =>
              setFile(
                e.target.files[0]
              )
            }
            className="
              w-full
              p-4
              border
              border-[#E8E6EF]
              rounded-xl
              mb-6
            "
          />

          <button
            onClick={uploadResume}
            disabled={uploading}
            className="
              bg-[#7367F0]
              hover:bg-[#6355E8]
              text-white
              px-8
              py-3
              rounded-xl
            "
          >
            {
              uploading
                ? "Uploading..."
                : "Upload Resume"
            }
          </button>

        </div>

        {/* Uploaded Resume */}

        {resume && (

          <div
            className="
              bg-white
              rounded-3xl
              border
              border-[#E8E6EF]
              p-8
              mb-8
            "
          >

            <h2
              className="
                text-2xl
                font-semibold
                mb-6
              "
            >
              Uploaded Resume
            </h2>

            <div
              className="
                grid
                md:grid-cols-2
                gap-6
              "
            >

              <div>

                <p className="text-gray-500">
                  File Name
                </p>

                <h3 className="font-semibold">
                  {resume.resumeFileName}
                </h3>

              </div>

              <div>

                <p className="text-gray-500">
                  Uploaded At
                </p>

                <h3 className="font-semibold">
                  {resume.uploadedAt}
                </h3>

              </div>

            </div>

            <a
              href={resume.resumeUrl}
              target="_blank"
              rel="noreferrer"
              className="
                inline-block
                mt-6
                bg-[#F5F3F8]
                px-6
                py-3
                rounded-xl
              "
            >
              View Resume
            </a>

          </div>

        )}

        {/* Hero Metrics */}

        <div
          className="
            grid
            grid-cols-1
            md:grid-cols-2
            xl:grid-cols-4
            gap-6
            mb-8
          "
        >

          {metrics.map(
            (metric, index) => (

              <div
                key={index}
                className="
                  bg-white
                  rounded-2xl
                  border
                  border-[#E8E6EF]
                  p-6
                "
              >

                <p className="text-gray-500">
                  {metric.title}
                </p>

                <h2
                  className="
                    text-4xl
                    font-bold
                    mt-2
                  "
                >
                  {metric.value ?? 0}%
                </h2>

              </div>

            )
          )}

        </div>

        {/* AI Summary */}

        <div
          className="
            bg-white
            rounded-3xl
            border
            border-[#E8E6EF]
            p-8
            mb-8
          "
        >

          <h2
            className="
              text-2xl
              font-semibold
              mb-4
            "
          >
            AI Resume Summary
          </h2>

          <p
            className="
              text-gray-600
              leading-8
            "
          >
            {data?.summary}
          </p>

        </div>

        {/* Strengths & Weaknesses */}

        <div
          className="
            grid
            grid-cols-1
            lg:grid-cols-2
            gap-6
            mb-8
          "
        >

          <div
            className="
              bg-white
              rounded-2xl
              border
              border-[#E8E6EF]
              p-6
            "
          >

            <h2
              className="
                text-xl
                font-semibold
                mb-4
              "
            >
              Strengths
            </h2>

            <div className="space-y-3">

              {data?.strengths?.map(
                (item, index) => (

                  <div
                    key={index}
                    className="
                      bg-green-50
                      text-green-700
                      px-4
                      py-3
                      rounded-xl
                    "
                  >
                    {item}
                  </div>

                )
              )}

            </div>

          </div>

          <div
            className="
              bg-white
              rounded-2xl
              border
              border-[#E8E6EF]
              p-6
            "
          >

            <h2
              className="
                text-xl
                font-semibold
                mb-4
              "
            >
              Areas To Improve
            </h2>

            <div className="space-y-3">

              {data?.weaknesses?.map(
                (item, index) => (

                  <div
                    key={index}
                    className="
                      bg-red-50
                      text-red-700
                      px-4
                      py-3
                      rounded-xl
                    "
                  >
                    {item}
                  </div>

                )
              )}

            </div>

          </div>

        </div>

        {/* Missing Skills */}

        <div
          className="
            bg-white
            rounded-2xl
            border
            border-[#E8E6EF]
            p-6
            mb-8
          "
        >

          <h2
            className="
              text-xl
              font-semibold
              mb-4
            "
          >
            Missing Skills
          </h2>

          <div className="flex flex-wrap gap-3">

            {gapData?.missingSkills?.map(
              (skill, index) => (

                <span
                  key={index}
                  className="
                    bg-red-50
                    text-red-600
                    px-4
                    py-2
                    rounded-full
                  "
                >
                  {skill}
                </span>

              )
            )}

          </div>

        </div>

        {/* Missing Projects */}

        <div
          className="
            bg-white
            rounded-2xl
            border
            border-[#E8E6EF]
            p-6
            mb-8
          "
        >

          <h2 className="text-xl font-semibold mb-4">
            Missing Projects
          </h2>

          <div className="space-y-3">

            {gapData?.missingProjects?.map(
              (project, index) => (

                <div
                  key={index}
                  className="
                    bg-[#F5F3F8]
                    px-4
                    py-3
                    rounded-xl
                  "
                >
                  {project}
                </div>

              )
            )}

          </div>

        </div>

        {/* Missing Certifications */}

        <div
          className="
            bg-white
            rounded-2xl
            border
            border-[#E8E6EF]
            p-6
            mb-8
          "
        >

          <h2 className="text-xl font-semibold mb-4">
            Missing Certifications
          </h2>

          <div className="space-y-3">

            {gapData?.missingCertifications?.map(
              (cert, index) => (

                <div
                  key={index}
                  className="
                    bg-[#F5F3F8]
                    px-4
                    py-3
                    rounded-xl
                  "
                >
                  {cert}
                </div>

              )
            )}

          </div>

        </div>

        {/* Recommendations */}

        <div
          className="
            bg-white
            rounded-2xl
            border
            border-[#E8E6EF]
            p-6
          "
        >

          <h2
            className="
              text-xl
              font-semibold
              mb-4
            "
          >
            AI Recommendations
          </h2>

          <div className="space-y-3">

            {data?.recommendations?.map(
              (item, index) => (

                <div
                  key={index}
                  className="
                    flex
                    gap-4
                    p-4
                    bg-[#F5F3F8]
                    rounded-xl
                  "
                >

                  <div
                    className="
                      w-8
                      h-8
                      rounded-full
                      bg-[#7367F0]
                      text-white
                      flex
                      items-center
                      justify-center
                    "
                  >
                    {index + 1}
                  </div>

                  <p>{item}</p>

                </div>

              )
            )}

          </div>

        </div>

      </div>

    </div>

  </>
);

}

export default ResumeCenterPage;