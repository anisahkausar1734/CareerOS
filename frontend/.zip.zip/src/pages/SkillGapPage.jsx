import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Topbar from "../components/Topbar";
function SkillGapPage() {

  const [data, setData] =
    useState(null);

  const [loading, setLoading] =
    useState(true);

  useEffect(() => {
    loadSkillGap();
  }, []);

  const loadSkillGap = async () => {

    try {

      const email =
        localStorage.getItem("email");

      const response =
        await axios.get(
          `http://localhost:8080/api/career/skill-gap/${email}`
        );

      setData(response.data);

    } catch (error) {

      console.log(error);

    } finally {

      setLoading(false);
    }
  };

  if (loading) {

    return (
      <h2 className="text-center mt-10">
        Loading Skill Gap Analysis...
      </h2>
    );
  }

  return (
  <>
    <Sidebar />

    <div
      className="
        ml-72
        min-h-screen
        bg-[#F5F3F8]
      "
    >

      <Topbar />

      <div className="p-8">

        <div
          className="
            bg-white
            rounded-2xl
            border
            border-[#E8E6EF]
            p-8
            mb-8
          "
        >

          <h1
            className="
              text-4xl
              font-bold
              text-[#4A4A4A]
              mb-2
            "
          >
            Skill Gap Analysis
          </h1>

          <p
            className="
              text-[#8A88A1]
            "
          >
            Discover the skills you need
            to achieve your dream role.
          </p>

        </div>

        <div
          className="
            grid
            grid-cols-1
            lg:grid-cols-3
            gap-6
          "
        >

          {/* Left Side */}

          <div
            className="
              lg:col-span-2
              space-y-6
            "
          >

            <div
              className="
                bg-white
                rounded-2xl
                border
                border-[#E8E6EF]
                p-6
              "
            >

              <h2
                className="
                  text-xl
                  font-semibold
                  mb-4
                "
              >
                Target Role
              </h2>

              <p
                className="
                  text-lg
                  text-[#7367F0]
                  font-semibold
                "
              >
                {data.targetRole}
              </p>

            </div>

            <div
              className="
                bg-white
                rounded-2xl
                border
                border-[#E8E6EF]
                p-6
              "
            >

              <h2
                className="
                  text-xl
                  font-semibold
                  mb-4
                "
              >
                Current Skills
              </h2>

              <div className="flex flex-wrap gap-3">

                {data.currentSkills?.map(
                  (skill, index) => (
                    <span
                      key={index}
                      className="
                        bg-[#F5F3F8]
                        px-4
                        py-2
                        rounded-xl
                      "
                    >
                      {skill}
                    </span>
                  )
                )}

              </div>

            </div>

            <div
              className="
                bg-white
                rounded-2xl
                border
                border-[#E8E6EF]
                p-6
              "
            >

              <h2
                className="
                  text-xl
                  font-semibold
                  mb-4
                "
              >
                Missing Skills
              </h2>

              <div className="flex flex-wrap gap-3">

                {data.missingSkills?.map(
                  (skill, index) => (
                    <span
                      key={index}
                      className="
                        bg-red-50
                        text-red-600
                        px-4
                        py-2
                        rounded-xl
                      "
                    >
                      {skill}
                    </span>
                  )
                )}

              </div>

            </div>

            <div
              className="
                bg-white
                rounded-2xl
                border
                border-[#E8E6EF]
                p-6
              "
            >

              <h2
                className="
                  text-xl
                  font-semibold
                  mb-4
                "
              >
                Priority Skills
              </h2>

              <div className="space-y-3">

                {data.prioritySkills?.map(
                  (skill, index) => (
                    <div
                      key={index}
                      className="
                        bg-[#F5F3F8]
                        p-3
                        rounded-xl
                      "
                    >
                      {index + 1}. {skill}
                    </div>
                  )
                )}

              </div>

            </div>

          </div>

          {/* Right Side */}

          <div className="space-y-6">

            <div
              className="
                bg-white
                rounded-2xl
                border
                border-[#E8E6EF]
                p-6
              "
            >

              <h2
                className="
                  text-lg
                  font-semibold
                  mb-3
                "
              >
                Skill Match
              </h2>

              <p
                className="
                  text-5xl
                  font-bold
                  text-[#7367F0]
                "
              >
                {data.skillMatchPercentage}%
              </p>

            </div>

            <div
              className="
                bg-white
                rounded-2xl
                border
                border-[#E8E6EF]
                p-6
              "
            >

              <h2
                className="
                  text-lg
                  font-semibold
                  mb-3
                "
              >
                Estimated Time
              </h2>

              <p>
                {data.estimatedTime}
              </p>

            </div>

            <div
              className="
                bg-white
                rounded-2xl
                border
                border-[#E8E6EF]
                p-6
              "
            >

              <h2
                className="
                  text-lg
                  font-semibold
                  mb-3
                "
              >
                Resources
              </h2>

              <div className="space-y-2">

                {data.recommendedResources?.map(
                  (resource, index) => (
                    <div key={index}>
                      • {resource}
                    </div>
                  )
                )}

              </div>

            </div>

          </div>

        </div>

      </div>

    </div>

  </>
);
}

export default SkillGapPage;
