import { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";

function ProfilePage() {

    const [profile, setProfile] = useState(null);

    const email = localStorage.getItem("email");

    useEffect(() => {
        fetchProfile();
    }, []);

    const fetchProfile = async () => {

        try {

            const response = await axios.get(
                `http://localhost:8080/api/student-profile/${email}`
            );

            setProfile(response.data);

        } catch (error) {

            console.error(error);

        }

    };

    if (!profile) {

        return (

            <div className="min-h-screen flex items-center justify-center">

                Loading...

            </div>

        );

    }

    return (

        <div className="min-h-screen bg-[#F7F7FB] flex">

            <Sidebar />

<main
    className="
        ml-72
        w-[calc(100vw-18rem)]
        min-h-screen
        overflow-y-auto
        px-10
        py-10
    "
>
<div className="w-full max-w-[1400px] mx-auto">
                    {/* ================= HEADER ================= */}

                    <div className="flex items-start justify-between mb-10">

                        <div>

                            <div
                                className="
                                    inline-flex
                                    items-center
                                    px-4
                                    py-2
                                    rounded-full
                                    bg-[#F5F3FF]
                                    text-[#7367F0]
                                    text-sm
                                    font-medium
                                    mb-5
                                "
                            >
                                Career Profile
                            </div>

                            <h1
                                className="
                                    text-[52px]
                                    leading-none
                                    font-bold
                                    text-[#1E2340]
                                "
                            >
                                My Profile
                            </h1>

                            <p
                                className="
                                    mt-5
                                    text-xl
                                    leading-10
                                    text-slate-500
                                    max-w-2xl
                                "
                            >
                                Manage your personal information,
                                academic details and career
                                preferences that power your
                                personalized CareerOS journey.
                            </p>

                        </div>

                        <button

                            onClick={() =>
                                window.location.href =
                                    "/profile/edit"
                            }

                            className="
                                bg-[#7367F0]
                                hover:bg-[#6558EB]
                                transition
                                text-white
                                rounded-3xl
                                px-8
                                py-5
                                font-semibold
                                shadow-md
                            "

                        >

                            Edit Details

                        </button>

                    </div>

                    {/* ================= PROFILE SUMMARY ================= */}

                    <div
    className="
        bg-white
        rounded-[32px]
        border
        border-[#ECEAF5]
        shadow-sm
        p-10
        mb-8
    "
>

    <div
className="
grid
grid-cols-1
xl:grid-cols-[1fr_430px]
gap-10
items-start
"
>
    

        {/* Left */}

       <div
className="
flex
items-center
gap-8
min-w-0
"
>

            <div
                className="
                    w-24
                    h-24
                    rounded-full
                    bg-gradient-to-br
                    from-[#7367F0]
                    to-[#8F82FF]
                    flex
                    items-center
                    justify-center
                    text-white
                    text-4xl
                    font-bold
                    shadow-md
                "
            >
                {profile.fullName?.charAt(0)}
            </div>

            <div>

                <h2
                    className="
                        text-[40px]
                        font-bold
                        text-[#1E2340]
                    "
                >
                    {profile.fullName}
                </h2>

                <p
                    className="
                        mt-2
                        text-2xl
                        text-slate-500
                    "
                >
                    {profile.dreamRole}
                </p>

            </div>

        </div>

        {/* Right */}

        <div
            className="
               grid
grid-cols-2
gap-5
w-full
            "
        >

            <SummaryCard
                title="Career Readiness"
                value={`${profile.careerReadiness || 0}%`}
                valueColor="text-green-600"
            />

            <SummaryCard
                title="Current Stage"
                value={
                    profile.currentStage
                        ?.replaceAll("_", " ")
                        ?.toLowerCase()
                        ?.replace(/\b\w/g, c => c.toUpperCase())
                        || "Profile Completed"
                }
            />

            <SummaryCard
                title="Resume Status"
                value={
                    profile.resumeCompleted
                        ? "Uploaded"
                        : "Not Uploaded"
                }
                valueColor={
                    profile.resumeCompleted
                        ? "text-green-600"
                        : "text-orange-500"
                }
            />

            <SummaryCard
                title="Skills"
                value={`${profile.skills?.length ?? 0} Skills`}
            />

        </div>

    </div>

</div>

{/* ================= INFORMATION ================= */}

<div
    className="
       grid
grid-cols-1
xl:grid-cols-2
gap-8
w-full
        mb-8
    "
>
    <div
    className="
       bg-white
rounded-[28px]
border
border-[#ECEAF5]
p-8
shadow-sm
w-full
min-w-0
    "
>

    <h3
        className="
            text-2xl
            font-bold
            text-[#1E2340]
            mb-8
        "
    >
        Personal Information
    </h3>

    <div className="space-y-6">

        <InfoRow
            label="Full Name"
            value={profile.fullName}
        />

        <InfoRow
            label="Email"
            value={profile.email}
        />

        <InfoRow
            label="Phone Number"
            value={profile.phoneNumber}
        />

    </div>

</div>

<div
    className="
       bg-white
rounded-[28px]
border
border-[#ECEAF5]
p-8
shadow-sm
w-full
min-w-0
    "
>

    <h3
        className="
            text-2xl
            font-bold
            text-[#1E2340]
            mb-8
        "
    >
        Academic Information
    </h3>

    <div className="space-y-6">

        <InfoRow
            label="College"
            value={profile.collegeName}
        />

        <InfoRow
            label="Degree"
            value={profile.degree}
        />

        <InfoRow
            label="Branch"
            value={profile.branch}
        />

        <InfoRow
            label="Current Year"
            value={profile.currentYear}
        />

        <InfoRow
            label="Graduation Year"
            value={profile.graduationYear}
        />

    </div>

</div>

</div>

{/* ================= CAREER ================= */}

<div
    className="
       grid
grid-cols-1
xl:grid-cols-2
gap-8
w-full
        mb-10
    "
>
    {/* ================= CAREER PROFILE ================= */}

<div
    className="
       bg-white
rounded-[28px]
border
border-[#ECEAF5]
p-8
shadow-sm
w-full
min-w-0
    "
>

    <h3
        className="
            text-2xl
            font-bold
            text-[#1E2340]
            mb-8
        "
    >
        Career Profile
    </h3>

    <div className="space-y-7">

        <InfoRow
            label="Dream Role"
            value={profile.dreamRole}
        />

        <div>

            <p
                className="
                    text-slate-500
                    font-medium
                    mb-4
                "
            >
                Current Skills
            </p>

            <div className="flex flex-wrap gap-3">

                {

                    profile.skills?.length > 0

                    ?

                    profile.skills.map((skill,index)=>(

                        <span

                            key={index}

                            className="
                                px-4
                                py-2
                                rounded-full
                                bg-[#F4F2FF]
                                text-[#7367F0]
                                text-sm
                                font-medium
                            "

                        >

                            {skill}

                        </span>

                    ))

                    :

                    <div
                        className="
                            w-full
                            rounded-2xl
                            bg-[#F8F9FC]
                            border
                            border-[#ECEAF5]
                            p-5
                            text-slate-500
                            text-sm
                        "
                    >

                        No skills added yet.
                        Start your journey by adding your first skill.

                    </div>

                }

            </div>

        </div>

        <InfoRow
            label="Resume Status"
            value={
                profile.resumeCompleted
                    ? "Uploaded"
                    : "Not Uploaded"
            }
        />

    </div>

</div>



{/* ================= CAREER JOURNEY ================= */}

<div
    className="
        bg-white
rounded-[28px]
border
border-[#ECEAF5]
p-8
shadow-sm
w-full
min-w-0
    "
>

    <h3
        className="
            text-2xl
            font-bold
            text-[#1E2340]
            mb-8
        "
    >
        Career Journey
    </h3>

    <div className="space-y-5">

        <JourneyRow
            title="Skill Gap Analysis"
            completed={profile.skillGapCompleted}
        />

        <JourneyRow
            title="Career Roadmap"
            completed={profile.roadmapCompleted}
        />

        <JourneyRow
            title="Resume Analysis"
            completed={profile.resumeCompleted}
        />

        <JourneyRow
            title="Mock Interview"
            completed={profile.interviewCompleted}
        />

        <JourneyRow
            title="Job Applications"
            completed={profile.jobsCompleted}
        />

    </div>

</div>

</div>

</div>

</main>

</div>

);

}

function SummaryCard({

    title,

    value,

    valueColor = "text-slate-900"

}) {

    return (

        <div
            className="
                bg-[#FAFAFD]
                border
                border-[#ECEAF5]
                rounded-3xl
                p-5
            "
        >

            <p
                className="
                    text-sm
                    text-slate-500
                "
            >
                {title}
            </p>

            <h4
                className={`
                    mt-2
                    text-xl
                    font-bold
                    ${valueColor}
                `}
            >
                {value}
            </h4>

        </div>

    );

}

function InfoRow({

    label,

    value

}) {

    return (

        <div
            className="
                grid
                grid-cols-[160px_1fr]
                gap-6
                items-center
                py-4
                border-b
                border-[#F1F2F6]
                last:border-none
            "
        >

            <p
                className="
                    text-slate-500
                    font-medium
                "
            >
                {label}
            </p>

            <p
                className="
                    text-[#1E2340]
                    font-semibold
                    break-words
                "
            >
                {value || "Not Added"}
            </p>

        </div>

    );

}

function JourneyRow({

    title,

    completed

}) {

    return (

        <div
            className="
                flex
                items-center
                justify-between
                gap-5
                border
                border-[#ECEAF5]
                rounded-2xl
                px-5
                py-4
            "
        >

            <div
                className="
                    flex
                    items-center
                    gap-4
                "
            >

                <div
                    className={`
                        w-3
                        h-3
                        rounded-full
                        ${
                            completed
                                ? "bg-green-500"
                                : "bg-slate-300"
                        }
                    `}
                />

                <p
                    className="
                        font-semibold
                        text-[#1E2340]
                    "
                >
                    {title}
                </p>

            </div>

            <span
                className={`
                    min-w-[100px]
                    text-center
                    px-3
                    py-2
                    rounded-full
                    text-xs
                    font-semibold
                    ${
                        completed
                            ? "bg-green-100 text-green-700"
                            : "bg-slate-100 text-slate-500"
                    }
                `}
            >
                {completed ? "Completed" : "Pending"}
            </span>

        </div>

    );

}

export default ProfilePage;